import numpy as np, math
from dsp_reference import *

PK, LS, HS = 'PK', 'LS', 'HS'

# id: (name, [(kind, f, gain, q)...], punch, extraLoudDb)
PRESETS = {
 'tws': ('TWS Sound', [
     (LS,   85, +3.0, 0.60),   # cuerpo de graves, sin subir el sub extremo
     (PK,  300, -1.6, 0.85),   # limpia boxiness / lodo
     (PK, 1800, +0.8, 0.90),   # cuerpo de voz
     (PK, 3100, +1.6, 1.00),   # presencia (canal auditivo ~2.7 kHz)
     (PK, 6200, -1.4, 2.20),   # corta aspereza de buds baratos (concha ~6 kHz)
     (HS,10500, +2.2, 0.70),   # aire: recupera lo que SBC/AAC se come
   ], 0.45, 0.0),
 'flat': ('Plano', [], 0.0, 0.0),
 'harman': ('Harman', [
     (LS, 105, +4.5, 0.70),
     (PK, 2800, +1.2, 1.00),
     (HS, 9000, -0.8, 0.70),
   ], 0.15, 0.0),
 'reggaeton': ('Reggaetón', [
     (LS,   55, +4.2, 0.80),
     (PK,   95, +1.2, 1.40),
     (PK,  240, -2.2, 0.90),
     (PK, 3400, +1.6, 1.00),
     (HS, 9500, +2.6, 0.70),
   ], 0.60, 2.0),
 'corridos': ('Corridos', [
     (LS,   90, +2.8, 0.70),   # tololoche / bajo sexto
     (PK,  250, -1.2, 0.90),
     (PK, 1700, +2.0, 0.90),   # acordeón / requinto
     (PK, 3200, +1.8, 1.10),   # voz y trompeta
     (PK, 6500, -1.0, 2.00),
     (HS,10000, +1.6, 0.70),
   ], 0.50, 1.0),
 'trap': ('Trap 808', [
     (LS,   45, +4.6, 0.80),   # 808
     (PK,   70, +1.2, 1.20),
     (PK,  150, -1.6, 1.00),   # evita que el 808 tape el kick
     (PK,  320, -2.0, 0.90),
     (PK, 4800, +1.6, 1.00),   # hi-hats / snare
     (HS,11000, +2.4, 0.70),
   ], 0.60, 2.0),
 'pop': ('Pop Radio', [
     (LS,   95, +2.2, 0.70),
     (PK,  320, -1.2, 0.90),
     (PK, 2900, +1.5, 1.00),
     (PK, 7000, +0.8, 1.20),
     (HS,10000, +2.4, 0.70),
   ], 0.50, 1.0),
 'rock': ('Rock', [
     (LS,   80, +2.6, 0.70),
     (PK,  450, -2.2, 0.80),
     (PK, 1300, -0.8, 0.90),
     (PK, 3200, +2.0, 1.00),
     (HS, 9000, +2.2, 0.70),
   ], 0.40, 1.0),
 'edm': ('EDM Club', [
     (LS,   50, +4.8, 0.80),
     (PK,  210, -1.8, 1.00),
     (PK, 1200, -0.6, 0.90),
     (PK, 5200, +1.4, 1.00),
     (HS,11000, +3.2, 0.70),
   ], 0.65, 2.0),
 'voz': ('Voz y Podcast', [
     (LS,  140, -4.0, 0.70),   # fuera rumbles / proximidad
     (PK,  260, -1.0, 1.00),
     (PK, 2500, +3.0, 0.90),
     (PK, 4800, +1.6, 1.20),
     (HS, 8500, -1.0, 0.70),
   ], 0.75, 1.0),
 'acustico': ('Acústico y Jazz', [
     (LS,  110, +1.6, 0.70),
     (PK,  500, -0.6, 0.90),
     (PK, 3000, +1.0, 1.00),
     (HS,12000, +1.8, 0.70),
   ], 0.15, 0.0),
 'cine': ('Cine', [
     (LS,   60, +4.0, 0.70),
     (PK,  250, -1.0, 0.90),
     (PK, 2200, +1.4, 0.90),   # diálogos
     (HS, 9000, +1.2, 0.70),
   ], 0.55, 1.0),
 'noche': ('Noche', [
     (LS,   90, -2.0, 0.70),   # no molestar a los vecinos
     (PK, 2800, +1.0, 1.00),
     (HS, 8000, -1.0, 0.70),
   ], 0.90, 0.0),
 'calle': ('Calle', [
     (LS,  100, +3.6, 0.70),   # el ruido se come los graves
     (PK,  400, -1.0, 0.90),
     (PK, 2800, +3.0, 0.90),   # y la voz
     (HS, 7500, +2.0, 0.70),
   ], 0.65, 3.0),
 'bajos-': ('Menos graves', [
     (LS,  120, -4.0, 0.70),
     (PK, 3000, +0.8, 1.00),
   ], 0.20, 0.0),
 'suave': ('Anti-fatiga', [
     (PK, 3500, -1.0, 1.00),
     (PK, 6500, -2.4, 1.80),
     (HS, 9000, -2.5, 0.70),
     (LS,   90, +1.0, 0.70),
   ], 0.35, 0.0),
}

BAND_F = [25, 31.5, 40, 50, 63, 80, 100, 125, 160, 200, 250, 315, 400, 500, 630, 800,
          1000, 1250, 1600, 2000, 2500, 3150, 4000, 5000, 6300, 8000, 10000, 12500, 16000]

def analyze(pid):
    name, flt, punch, extra = PRESETS[pid]
    g = curve(flt, BAND_F) if flt else np.zeros(len(BAND_F))
    mx = max(0.0, g.max())
    pre = -0.8 * mx
    # pink noise: equal power per 1/3 octave band -> mean of linear power
    pink = 10 * math.log10(np.mean(10 ** (g / 10)))
    match = -(pre + pink)
    return g, mx, pre, pink, match

if __name__ == '__main__':
    import matplotlib; matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fr = np.geomspace(20, 20000, 400)
    fig, axes = plt.subplots(4, 4, figsize=(18, 11), sharex=True, sharey=True)
    for ax, pid in zip(axes.flat, PRESETS):
        name, flt, punch, extra = PRESETS[pid]
        c = curve(flt, fr) if flt else np.zeros_like(fr)
        ax.semilogx(fr, c, lw=2)
        g, mx, pre, pink, match = analyze(pid)
        ax.plot(BAND_F, g, 'o', ms=2.5)
        ax.set_title('%s  max%+.1f pre%+.1f pink%+.1f match%+.1f' % (name, mx, pre, pink, match), fontsize=8)
        ax.set_ylim(-8, 8); ax.grid(alpha=.3)
        print('%-16s maxBoost %+5.2f  preamp %+5.2f  pinkΔ %+5.2f  levelMatch %+5.2f  punch %.2f extra %+.1f' % (name, mx, pre, pink, match, punch, extra))
    plt.tight_layout(); plt.savefig('presets.png', dpi=70)
