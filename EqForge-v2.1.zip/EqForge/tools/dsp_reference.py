import numpy as np, math

FS = 48000.0

# ---------- band table (mirrors Bands.kt) ----------
CENTERS = [25, 31.5, 40, 50, 63, 80, 100, 125, 160, 200, 250, 315, 400, 500, 630, 800,
           1000, 1250, 1600, 2000, 2500, 3150, 4000, 5000, 6300, 8000, 10000, 12500, 16000]
SUBSONIC_CUT = 20.0
CUTOFFS = [SUBSONIC_CUT] + [math.sqrt(CENTERS[i] * CENTERS[i + 1]) for i in range(len(CENTERS) - 1)] + [20000.0]
# band 0 = [0, 20] subsonic ; band i (1..29) -> centers[i-1], upper edge = cutoffs[i]
# NOTE: len(CUTOFFS) == 1 + 28 + 1 = 30 ; bands = 30  (subsonic + 29 centres)
assert len(CUTOFFS) == 30, len(CUTOFFS)

# ---------- RBJ biquads ----------
def coeffs(kind, f0, gain_db, q):
    A = 10 ** (gain_db / 40.0)
    w0 = 2 * math.pi * f0 / FS
    cw, sw = math.cos(w0), math.sin(w0)
    al = sw / (2 * q)
    if kind == 'PK':
        b = [1 + al * A, -2 * cw, 1 - al * A]
        a = [1 + al / A, -2 * cw, 1 - al / A]
    elif kind == 'LS':
        s = 2 * math.sqrt(A) * al
        b = [A * ((A + 1) - (A - 1) * cw + s), 2 * A * ((A - 1) - (A + 1) * cw), A * ((A + 1) - (A - 1) * cw - s)]
        a = [(A + 1) + (A - 1) * cw + s, -2 * ((A - 1) + (A + 1) * cw), (A + 1) + (A - 1) * cw - s]
    elif kind == 'HS':
        s = 2 * math.sqrt(A) * al
        b = [A * ((A + 1) + (A - 1) * cw + s), -2 * A * ((A - 1) + (A + 1) * cw), A * ((A + 1) + (A - 1) * cw - s)]
        a = [(A + 1) - (A - 1) * cw + s, 2 * ((A - 1) - (A + 1) * cw), (A + 1) - (A - 1) * cw - s]
    return b, a

def mag_db(kind, f0, gain_db, q, f):
    """closed-form |H|^2 as will be written in Kotlin (no complex numbers)"""
    b, a = coeffs(kind, f0, gain_db, q)
    w = 2 * math.pi * f / FS
    c1, c2 = math.cos(w), math.cos(2 * w)
    num = b[0]**2 + b[1]**2 + b[2]**2 + 2 * (b[0]*b[1] + b[1]*b[2]) * c1 + 2 * b[0]*b[2] * c2
    den = a[0]**2 + a[1]**2 + a[2]**2 + 2 * (a[0]*a[1] + a[1]*a[2]) * c1 + 2 * a[0]*a[2] * c2
    return 10 * math.log10(max(num, 1e-20) / max(den, 1e-20))

def curve(filters, freqs):
    return np.array([sum(mag_db(k, f0, g, q, f) for (k, f0, g, q) in filters) for f in freqs])

# ---------- ISO 226:2003 (tables verified vs. Tackett iso226.m) ----------
ISO_F  = [20,25,31.5,40,50,63,80,100,125,160,200,250,315,400,500,630,800,1000,1250,1600,2000,2500,3150,4000,5000,6300,8000,10000,12500]
ISO_AF = [0.532,0.506,0.480,0.455,0.432,0.409,0.387,0.367,0.349,0.330,0.315,0.301,0.288,0.276,0.267,0.259,0.253,0.250,0.246,0.244,0.243,0.243,0.243,0.242,0.242,0.245,0.254,0.271,0.301]
ISO_LU = [-31.6,-27.2,-23.0,-19.1,-15.9,-13.0,-10.3,-8.1,-6.2,-4.5,-3.1,-2.0,-1.1,-0.4,0.0,0.3,0.5,0.0,-2.7,-4.1,-1.0,1.7,2.5,1.2,-2.1,-7.1,-11.2,-10.7,-3.1]
ISO_TF = [78.5,68.7,59.5,51.1,44.0,37.5,31.5,26.5,22.1,17.9,14.4,11.4,8.6,6.2,4.4,3.0,2.2,2.4,3.5,1.7,-1.3,-4.2,-6.0,-5.4,-1.5,6.0,12.6,13.9,12.3]

def iso_spl(phon):
    out = []
    for af, lu, tf in zip(ISO_AF, ISO_LU, ISO_TF):
        Af = 4.47e-3 * (10 ** (0.025 * phon) - 1.15) + (0.4 * 10 ** ((tf + lu) / 10 - 9)) ** af
        out.append(10 / af * math.log10(Af) - lu + 94)
    return np.array(out)

def iso_shape(phon, f):
    """SPL needed at f minus phon (== 0 at 1 kHz). log-f interpolation, clamped beyond table."""
    spl = iso_spl(phon) - phon
    return float(np.interp(math.log(f), np.log(ISO_F), spl))

def loudness_comp(v, f, ref=80.0, lo=35.0, span=45.0):
    listen = lo + span * v
    return iso_shape(listen, f) - iso_shape(ref, f)

if __name__ == '__main__':
    # sanity: ISO 40 phon contour: 1 kHz == 40, 20 Hz ~ 99.85, 100 Hz ~ 51.5
    s = iso_spl(40)
    print('40phon  20Hz %.2f  100Hz %.2f  1k %.2f  3.15k %.2f  12.5k %.2f' % (s[0], s[7], s[17], s[22], s[28]))

# perceived-loudness weights from ISO 226 (70 phon): weight = 10^(-shape/10) ; bass needs more SPL -> counts less
def loud_weights(phon=70.0):
    return np.array([10 ** (-iso_shape(phon, f) / 10.0) for f in CENTERS])

def perceived_gain_db(gains):
    w = loud_weights()
    return 10 * math.log10(float(np.sum(w * 10 ** (np.array(gains) / 10.0)) / np.sum(w)))
