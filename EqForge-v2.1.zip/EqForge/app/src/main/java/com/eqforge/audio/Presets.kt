package com.eqforge.audio

/**
 * Catálogo de fábrica. Cada preset es una lista de filtros paramétricos con
 * frecuencia, ganancia y Q exactas (curvas validadas numéricamente: ningún
 * preset pasa de +4.8 dB de pico, y el headroom se compensa solo).
 *
 * Fundamentos:
 *  - TWS Sound: target tipo Harman (Olive: 64% de oyentes prefieren ese
 *    perfil) con +2 dB de graves (sesgo "consumer" de JBL), limpieza de
 *    lodo a 300 Hz, presencia en el pico del canal auditivo (~2.7 kHz), una
 *    muesca estrecha en 6.2 kHz (resonancia de concha) para que no cansen
 *    los buds baratos, y aire en 10.5 kHz para recuperar lo que SBC/AAC se
 *    comen.
 *  - Géneros: la zona crítica de cada estilo (808 en 40-60 Hz, acordeón en
 *    1.7 kHz, hi-hats en 5 kHz...), sin pasar de lo razonable.
 */
object Presets {

    private fun pk(f: Float, g: Float, q: Float) = Filter(FilterType.PEAK, f, g, q)
    private fun ls(f: Float, g: Float, q: Float) = Filter(FilterType.LOW_SHELF, f, g, q)
    private fun hs(f: Float, g: Float, q: Float) = Filter(FilterType.HIGH_SHELF, f, g, q)

    const val DEFAULT_ID = "tws"
    const val SPEAKER_ID = "bocina"
    const val FLAT_ID = "flat"

    val builtIn: List<Preset> = listOf(
        Preset(
            "tws", "TWS Sound", "Graves con cuerpo, voces al frente, brillo limpio", Cat.SIGNATURE,
            listOf(ls(85f, 3.0f, 0.60f), pk(300f, -1.6f, 0.85f), pk(1800f, 0.8f, 0.90f), pk(3100f, 1.6f, 1.00f),
                pk(6200f, -1.4f, 2.20f), hs(10500f, 2.2f, 0.70f)),
            punch = 0.45f, builtIn = true
        ),
        Preset("flat", "Plano", "Sin color. Solo headroom y limitador", Cat.REFERENCE, emptyList(), 0f, 0f, true),
        Preset(
            "harman", "Harman", "El target que prefiere la mayoría de oyentes", Cat.REFERENCE,
            listOf(ls(105f, 4.5f, 0.70f), pk(2800f, 1.2f, 1.00f), hs(9000f, -0.8f, 0.70f)),
            punch = 0.15f, builtIn = true
        ),
        Preset(
            "acustico", "Acústico y Jazz", "Natural, cálido, con aire", Cat.REFERENCE,
            listOf(ls(110f, 1.6f, 0.70f), pk(500f, -0.6f, 0.90f), pk(3000f, 1.0f, 1.00f), hs(12000f, 1.8f, 0.70f)),
            punch = 0.15f, builtIn = true
        ),
        Preset(
            "reggaeton", "Reggaetón", "Sub profundo, kick seco, hi-hats nítidos", Cat.GENRE,
            listOf(ls(55f, 4.2f, 0.80f), pk(95f, 1.2f, 1.40f), pk(240f, -2.2f, 0.90f), pk(3400f, 1.6f, 1.00f), hs(9500f, 2.6f, 0.70f)),
            punch = 0.60f, builtIn = true
        ),
        Preset(
            "corridos", "Corridos y Regional", "Tololoche con cuerpo, acordeón y trompeta al frente", Cat.GENRE,
            listOf(ls(90f, 2.8f, 0.70f), pk(250f, -1.2f, 0.90f), pk(1700f, 2.0f, 0.90f), pk(3200f, 1.8f, 1.10f),
                pk(6500f, -1.0f, 2.00f), hs(10000f, 1.6f, 0.70f)),
            punch = 0.50f, builtIn = true
        ),
        Preset(
            "trap", "Trap 808", "808 controlado, hi-hats que cortan", Cat.GENRE,
            listOf(ls(45f, 4.6f, 0.80f), pk(70f, 1.2f, 1.20f), pk(150f, -1.6f, 1.00f), pk(320f, -2.0f, 0.90f),
                pk(4800f, 1.6f, 1.00f), hs(11000f, 2.4f, 0.70f)),
            punch = 0.60f, builtIn = true
        ),
        Preset(
            "pop", "Pop Radio", "Brillante, pulido, listo para cantar", Cat.GENRE,
            listOf(ls(95f, 2.2f, 0.70f), pk(320f, -1.2f, 0.90f), pk(2900f, 1.5f, 1.00f), pk(7000f, 0.8f, 1.20f), hs(10000f, 2.4f, 0.70f)),
            punch = 0.50f, builtIn = true
        ),
        Preset(
            "rock", "Rock", "Guitarras con mordida, batería viva", Cat.GENRE,
            listOf(ls(80f, 2.6f, 0.70f), pk(450f, -2.2f, 0.80f), pk(1300f, -0.8f, 0.90f), pk(3200f, 2.0f, 1.00f), hs(9000f, 2.2f, 0.70f)),
            punch = 0.40f, builtIn = true
        ),
        Preset(
            "edm", "EDM Club", "Sub de pista y aire de sobra", Cat.GENRE,
            listOf(ls(50f, 4.8f, 0.80f), pk(210f, -1.8f, 1.00f), pk(1200f, -0.6f, 0.90f), pk(5200f, 1.4f, 1.00f), hs(11000f, 3.2f, 0.70f)),
            punch = 0.65f, builtIn = true
        ),
        Preset(
            "cine", "Cine", "Impacto abajo, diálogos claros", Cat.GENRE,
            listOf(ls(60f, 4.0f, 0.70f), pk(250f, -1.0f, 0.90f), pk(2200f, 1.4f, 0.90f), hs(9000f, 1.2f, 0.70f)),
            punch = 0.55f, builtIn = true
        ),
        Preset(
            "noche", "Noche", "Bajito sin perder detalle ni molestar", Cat.SCENE,
            listOf(ls(90f, -2.0f, 0.70f), pk(2800f, 1.0f, 1.00f), hs(8000f, -1.0f, 0.70f)),
            punch = 0.90f, builtIn = true
        ),
        Preset(
            "calle", "Calle", "Graves y voz que sobreviven al ruido", Cat.SCENE,
            listOf(ls(100f, 3.6f, 0.70f), pk(400f, -1.0f, 0.90f), pk(2800f, 3.0f, 0.90f), hs(7500f, 2.0f, 0.70f)),
            punch = 0.65f, extraDb = 3f, builtIn = true
        ),
        Preset(
            "voz", "Voz y Podcast", "Inteligibilidad máxima, sin retumbe", Cat.SCENE,
            listOf(ls(140f, -4.0f, 0.70f), pk(260f, -1.0f, 1.00f), pk(2500f, 3.0f, 0.90f), pk(4800f, 1.6f, 1.20f), hs(8500f, -1.0f, 0.70f)),
            punch = 0.75f, builtIn = true
        ),
        Preset(
            "bocina", "Bocina del cel", "Sin graves que la bocina no puede dar, más voz", Cat.SCENE,
            listOf(ls(160f, -5.0f, 0.70f), pk(2200f, 2.0f, 0.90f), pk(4500f, 1.5f, 1.00f), hs(9000f, 1.5f, 0.70f)),
            punch = 0.60f, builtIn = true
        ),
        Preset(
            "bajos-", "Menos graves", "Para audífonos que ya traen de sobra", Cat.SCENE,
            listOf(ls(120f, -4.0f, 0.70f), pk(3000f, 0.8f, 1.00f)),
            punch = 0.20f, builtIn = true
        ),
        Preset(
            "suave", "Anti-fatiga", "Agudos domados para escuchar horas", Cat.SCENE,
            listOf(pk(3500f, -1.0f, 1.00f), pk(6500f, -2.4f, 1.80f), hs(9000f, -2.5f, 0.70f), ls(90f, 1.0f, 0.70f)),
            punch = 0.35f, builtIn = true
        )
    )

    fun find(id: String, user: List<Preset>): Preset? =
        builtIn.firstOrNull { it.id == id } ?: user.firstOrNull { it.id == id }

    val default: Preset get() = builtIn.first { it.id == DEFAULT_ID }

    /** Estado de fábrica: TWS Sound activo. */
    fun factoryState(): SoundState {
        val p = default
        return SoundState(
            enabled = true,
            presetId = p.id,
            filters = p.filters,
            punch = p.punch,
            extraDb = p.extraDb
        )
    }
}
