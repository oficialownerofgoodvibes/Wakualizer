package com.eqforge.game

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import com.eqforge.audio.Forge

/**
 * Detecta qué app está al frente leyendo los eventos de UsageStatsManager (requiere el
 * permiso especial "Acceso de uso"). Sondea cada segundo; entrar al juego es inmediato y
 * salir exige 3 sondeos seguidos fuera (evita parpadeos al cambiar de app un instante).
 */
class GameWatcher(private val ctx: Context) {

    private companion object {
        const val POLL_MS = 1000L
        const val AWAY_TICKS = 3
        const val FIRST_WINDOW_MS = 10 * 60_000L
        val IGNORED = setOf("com.android.systemui")
    }

    private val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
    private val main = Handler(Looper.getMainLooper())
    private var lastQuery = 0L
    private var fg: String? = null
    private var away = 0
    private var running = false

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            try { poll() } catch (e: Throwable) { /* sin permiso o servicio caído: se reintenta */ }
            main.postDelayed(this, POLL_MS)
        }
    }

    fun start() {
        if (running) return
        running = true
        main.post(tick)
    }

    fun stop() {
        running = false
        main.removeCallbacks(tick)
    }

    @Suppress("DEPRECATION")
    private fun poll() {
        val gs = Forge.gameSettings.value
        if (!gs.detect || !Perms.hasUsageAccess(ctx)) {
            if (Forge.game.value.active && !Forge.game.value.test) Forge.leaveGame()
            return
        }
        val now = System.currentTimeMillis()
        val begin = if (lastQuery == 0L) now - FIRST_WINDOW_MS else lastQuery - 1000L
        lastQuery = now

        val events = usm.queryEvents(begin, now)
        val e = UsageEvents.Event()
        var latest = fg
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            val pkg = e.packageName ?: continue
            if (pkg in IGNORED) continue
            when (e.eventType) {
                UsageEvents.Event.MOVE_TO_FOREGROUND -> latest = pkg
                UsageEvents.Event.MOVE_TO_BACKGROUND -> if (pkg == latest) latest = null
            }
        }
        fg = latest

        val inGame = latest != null && latest in gs.watched
        val cur = Forge.game.value
        if (cur.test) return // el botón "Probar" manda sobre la detección
        if (inGame) {
            away = 0
            if (!cur.active || cur.pkg != latest) Forge.enterGame(latest!!)
        } else if (cur.active) {
            if (++away >= AWAY_TICKS) { away = 0; Forge.leaveGame() }
        }
    }
}
