package com.eqforge.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.eqforge.audio.Forge
import com.eqforge.game.AppEntry
import com.eqforge.game.Apps
import com.eqforge.game.Perms
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

@Composable
fun GameScreen() {
    val ctx = LocalContext.current
    val gs by Forge.gameSettings.collectAsState()
    val game by Forge.game.collectAsState()
    val status by Forge.status.collectAsState()
    val tick by Forge.permTick.collectAsState()

    // Se re-leen al volver de Ajustes (MainActivity.onResume sube permTick).
    val usage = remember(tick) { Perms.hasUsageAccess(ctx) }
    val overlay = remember(tick) { Perms.canOverlay(ctx) }
    val spotifyInstalled = remember(tick) { Apps.spotifyInstalled(ctx) }
    val spotifyHooked = status.sessions.any { it.ok && it.pkg != null && it.pkg in Apps.SPOTIFY }
    var picker by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column(Modifier.padding(top = 8.dp)) {
            T("Modo Juego", 30, C.text, font = Cond)
            T("Música sin tapar los pasos", 13, C.dim)
        }

        // --------------------------------------------------------------- estado
        GCard("Estado") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(if (game.active) C.hot else C.faint))
                Spacer(Modifier.width(10.dp))
                T(
                    when {
                        !game.active -> "Esperando un juego"
                        game.test -> "Modo de prueba activo"
                        else -> "Jugando ${game.label}"
                    },
                    16, C.text, FontWeight.Medium, modifier = Modifier.weight(1f), maxLines = 2
                )
            }
            T(
                "Al abrir un juego vigilado te llega una notificación. Tócala para sacar la barra de volumen de Spotify encima del juego; " +
                    "también trae botones − / + por si no quieres salir de la partida.",
                12, C.faint, maxLines = 6
            )
            if (!game.active || game.test) {
                Pill(
                    if (game.test) "Salir de la prueba" else "Probar ahora (sin abrir el juego)",
                    { Forge.setGameTest(!game.test) },
                    Modifier.fillMaxWidth(), filled = !game.test
                )
            }
        }

        // ------------------------------------------------------------- permisos
        GCard("Permisos y conexión") {
            PermRow(
                "Acceso de uso", usage,
                okText = "detecta qué app está abierta",
                badText = "falta: sin esto no se detecta el juego",
                action = "Dar permiso"
            ) { ctx.startActivity(Perms.usageSettings()) }
            PermRow(
                "Barra flotante", overlay,
                okText = "se muestra encima del juego",
                badText = "falta: sin esto la notificación solo trae − / +",
                action = "Dar permiso"
            ) { ctx.startActivity(Perms.overlaySettings(ctx)) }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(if (spotifyHooked) C.ice else C.faint))
                Spacer(Modifier.width(10.dp))
                T("Spotify", 13, C.text, FontWeight.Medium)
                Spacer(Modifier.width(10.dp))
                T(
                    when {
                        !spotifyInstalled -> "no está instalado"
                        spotifyHooked -> "enganchado: su volumen se puede controlar"
                        else -> "dale play a una canción para engancharlo"
                    },
                    12, C.dim, modifier = Modifier.weight(1f), maxLines = 2
                )
            }
        }

        // --------------------------------------------------------------- música
        GCard("Música en el juego") {
            GSlider("Spotify en el juego", "${(gs.musicVolume * 100).roundToInt()}%", gs.musicVolume, 0f, 1f, 0.05f) {
                Forge.setMusicVolume(it)
            }
            T(
                "Solo baja a Spotify; el volumen del juego no se toca. Se aplica al abrir el juego y Spotify vuelve a 100 % al salir.",
                12, C.faint, maxLines = 4
            )
            GToggle(
                "Hueco para pasos",
                "Recorta un poco los medios de la música (1.8 y 3.6 kHz) para que los pasos no queden tapados.",
                gs.carve
            ) { on -> Forge.updateGame { it.copy(carve = on) } }
            if (gs.carve) {
                GSlider("Profundidad del hueco", "${(gs.carveStrength * 100).roundToInt()}%", gs.carveStrength, 0f, 1f, 0.05f) { v ->
                    Forge.updateGame { it.copy(carveStrength = v) }
                }
            }
        }

        // --------------------------------------------------------------- juegos
        GCard("Juegos vigilados") {
            GToggle("Detectar automáticamente", "Avisa al abrir cualquier app de esta lista.", gs.detect) { on ->
                Forge.updateGame { it.copy(detect = on) }
            }
            if (gs.watched.isEmpty()) {
                T("Ninguno todavía. Elige tus juegos de la lista de apps instaladas.", 13, C.dim, maxLines = 3)
            }
            gs.watched.sortedBy { Apps.label(ctx, it).lowercase() }.forEach { pkg ->
                AppRow(pkg, Apps.label(ctx, pkg), true) { Forge.updateGame { s -> s.copy(watched = s.watched - pkg) } }
            }
            Pill("Elegir de las apps instaladas", { picker = true }, Modifier.fillMaxWidth(), filled = true)
        }
        Spacer(Modifier.height(24.dp))
    }

    if (picker) AppPicker { picker = false }
}

// ------------------------------------------------------------------ selector

@Composable
private fun AppPicker(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val gs by Forge.gameSettings.collectAsState()
    val apps by produceState(emptyList<AppEntry>()) {
        value = withContext(Dispatchers.Default) { Apps.launchable(ctx) }
    }
    var all by remember { mutableStateOf(false) }
    val shown = if (all) apps else apps.filter { it.suggested || it.pkg in gs.watched }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.fillMaxSize().background(C.bg).statusBarsPadding().navigationBarsPadding().padding(16.dp)
        ) {
            T("Apps instaladas", 24, C.text, font = Cond)
            T("Activa las que cuenten como juego (${apps.size} apps con icono)", 12, C.dim, maxLines = 2)
            Spacer(Modifier.height(10.dp))
            Segmented(listOf("Sugeridas", "Todas"), if (all) 1 else 0, { all = it == 1 })
            Spacer(Modifier.height(10.dp))
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (shown.isEmpty()) {
                    item { T("No encontré juegos conocidos. Cambia a «Todas».", 13, C.faint, maxLines = 3) }
                }
                items(shown, key = { it.pkg }) { a ->
                    AppRow(a.pkg, a.label, a.pkg in gs.watched) { on ->
                        Forge.updateGame { s -> s.copy(watched = if (on) s.watched + a.pkg else s.watched - a.pkg) }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Pill("Listo", onDismiss, Modifier.fillMaxWidth(), filled = true)
        }
    }
}

// ------------------------------------------------------------------ piezas

@Composable
private fun AppRow(pkg: String, label: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        AppIcon(pkg)
        Spacer(Modifier.width(12.dp))
        T(label, 14, C.text, FontWeight.Medium, modifier = Modifier.weight(1f), maxLines = 1)
        Spacer(Modifier.width(12.dp))
        Toggle(on, onChange)
    }
}

@Composable
private fun AppIcon(pkg: String) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, pkg) {
        value = withContext(Dispatchers.Default) { Apps.icon(ctx, pkg) }
    }
    Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(C.surface2)) {
        bmp?.let { Image(bitmap = it, contentDescription = null, modifier = Modifier.fillMaxSize()) }
    }
}

@Composable
private fun PermRow(title: String, ok: Boolean, okText: String, badText: String, action: String, onAction: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(if (ok) C.ice else C.hot))
            Spacer(Modifier.width(10.dp))
            T(title, 13, C.text, FontWeight.Medium)
            Spacer(Modifier.width(10.dp))
            T(if (ok) okText else badText, 12, C.dim, modifier = Modifier.weight(1f), maxLines = 2)
        }
        if (!ok) Pill(action, onAction, Modifier.fillMaxWidth())
    }
}

@Composable
private fun GCard(title: String, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().card().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        T(title, 20, C.text, font = Cond)
        content()
    }
}

@Composable
private fun GSlider(label: String, valueText: String, value: Float, min: Float, max: Float, step: Float, onChange: (Float) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            T(label, 13, C.text, FontWeight.Medium, modifier = Modifier.weight(1f))
            T(valueText, 13, C.dim)
        }
        HSlider(value, onChange, min, max, color = C.ice, step = step)
    }
}

@Composable
private fun GToggle(title: String, sub: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            T(title, 14, C.text, FontWeight.Medium)
            T(sub, 12, C.faint, maxLines = 3)
        }
        Spacer(Modifier.width(12.dp))
        Toggle(on, onChange)
    }
}
