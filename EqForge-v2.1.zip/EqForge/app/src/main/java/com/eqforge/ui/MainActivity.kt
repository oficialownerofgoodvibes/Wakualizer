package com.eqforge.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color as AColor
import android.media.audiofx.AudioEffect
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.eqforge.audio.Forge
import com.eqforge.audio.Spectrum
import com.eqforge.service.DspService

class MainActivity : ComponentActivity() {

    private val micGranted = mutableStateOf(false)
    private val visible = mutableStateOf(false)
    private val jumpTab = mutableStateOf<Int?>(null)

    companion object {
        const val EXTRA_OPEN_GAME = "com.eqforge.extra.OPEN_GAME"
        const val TAB_GAME = 3
    }

    private val permissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        micGranted.value = hasMic()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)

        micGranted.value = hasMic()
        DspService.start(this)
        handleIntent(intent)
        requestMissingPermissions()

        setContent {
            val status by Forge.status.collectAsState()
            val sid = status.sessions.lastOrNull { it.ok }?.id ?: 0
            val mic by micGranted
            val vis by visible

            // El analizador sigue a Spotify: se engancha a su sesión (o a la global) y se apaga en segundo plano.
            LaunchedEffect(mic, vis, sid) {
                if (mic && vis) {
                    if (!Spectrum.start(sid) && sid != 0) Spectrum.start(0)
                } else {
                    Spectrum.stop()
                }
            }

            val jump by jumpTab
            EqApp(mic, jump, { jumpTab.value = null }) { permissions.launch(arrayOf(Manifest.permission.RECORD_AUDIO)) }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        visible.value = true
    }

    override fun onResume() {
        super.onResume()
        // Volvemos de Ajustes: la pestaña Juego re-lee los permisos.
        Forge.permTick.value = Forge.permTick.value + 1
    }

    override fun onStop() {
        visible.value = false
        super.onStop()
    }

    override fun onDestroy() {
        Spectrum.stop()
        super.onDestroy()
    }

    /** Spotify / YT Music abren EqForge con la sesión de audio en los extras. */
    private fun handleIntent(intent: Intent?) {
        if (intent?.getBooleanExtra(EXTRA_OPEN_GAME, false) == true) jumpTab.value = TAB_GAME
        if (intent?.action == AudioEffect.ACTION_DISPLAY_AUDIO_EFFECT_CONTROL_PANEL) {
            val sid = intent.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, 0)
            val pkg = intent.getStringExtra(AudioEffect.EXTRA_PACKAGE_NAME)
            if (sid > 0) Forge.engine.openSession(sid, pkg)
        }
    }

    private fun hasMic(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun requestMissingPermissions() {
        val want = ArrayList<String>()
        if (!hasMic()) want += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) want += Manifest.permission.POST_NOTIFICATIONS
        if (Build.VERSION.SDK_INT >= 31 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) want += Manifest.permission.BLUETOOTH_CONNECT
        if (want.isNotEmpty()) permissions.launch(want.toTypedArray())
    }
}

@Composable
fun EqApp(micGranted: Boolean, jump: Int?, onJumpDone: () -> Unit, onRequestMic: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    LaunchedEffect(jump) {
        if (jump != null) { tab = jump; onJumpDone() }
    }
    Column(Modifier.fillMaxSize().background(C.bg).statusBarsPadding()) {
        Box(Modifier.weight(1f)) {
            Crossfade(targetState = tab, label = "tab") { t ->
                when (t) {
                    0 -> HomeScreen(micGranted, onRequestMic) { tab = 1 }
                    1 -> PresetsScreen()
                    2 -> LabScreen()
                    else -> GameScreen()
                }
            }
        }
        NavBar(tab) { tab = it }
    }
}

@Composable
private fun NavBar(selected: Int, onSelect: (Int) -> Unit) {
    Column(Modifier.fillMaxWidth().background(C.surface)) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(C.line))
        Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(vertical = 8.dp)) {
            listOf("Sonido", "Presets", "Lab", "Juego").forEachIndexed { i, label ->
                val on = i == selected
                val c = if (on) C.hot else C.faint
                Column(
                    Modifier.weight(1f).tap { onSelect(i) }.padding(vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    NavIcon(i, c)
                    T(label, 11, c, if (on) FontWeight.Medium else FontWeight.Normal, align = TextAlign.Center)
                }
            }
        }
    }
}
