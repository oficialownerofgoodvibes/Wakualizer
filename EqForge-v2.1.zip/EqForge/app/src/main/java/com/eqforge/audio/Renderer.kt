package com.eqforge.audio

import kotlin.math.max
import kotlin.math.min

data class MbcParams(
    val thresholdDb: Float,
    val ratio: Float,
    val attackMs: Float,
    val releaseMs: Float,
    val kneeDb: Float,
    val postGainDb: Float
)

/** Resultado listo para escribir en el efecto. Todo en dB / ms. */
class Rendered(
    /** size = Bands.count (banda 0 = subsónico). */
    val bandGains: FloatArray,
    val inputGainDb: Float,
    val mbcEnabled: Boolean,
    val mbc: List<MbcParams>,
    val limiterThresholdDb: Float,
    val limiterPostGainDb: Float,
    val bassBoost: Int,
    val virtualizer: Int,
    // Diagnóstico para la UI
    val peakBoostDb: Float,
    val levelMatchDb: Float,
    val loudnessCompDb: FloatArray
)

object Renderer {

    // Base del compresor multibanda: threshold, ratio, ataque, release.
    // Ataque lento en graves = deja pasar el transitorio del kick (punch);
    // ataque rápido en agudos = doma sibilancia. Release de Spotify "Loud": 100 ms.
    private val base = listOf(
        floatArrayOf(-22f, 2.4f, 30f, 160f),
        floatArrayOf(-24f, 1.7f, 22f, 150f),
        floatArrayOf(-26f, 1.9f, 12f, 120f),
        floatArrayOf(-28f, 2.2f, 5f, 80f)
    )

    const val LIMITER_ATTACK_MS = 5f      // igual que el limitador de Spotify "Loud"
    const val LIMITER_RELEASE_MS = 100f
    const val LIMITER_RATIO = 10f
    const val MAX_POST_GAIN_DB = 8.5f
    const val MAX_LEVEL_MATCH_DB = 3.5f

    fun render(s: SoundState, volume: Float): Rendered {
        val all = s.filters + s.macros.asFilters()
        val comp = if (s.smartLoudness) Psycho.loudnessComp(volume, s.smartStrength)
        else FloatArray(Bands.centers.size)

        val curve = if (all.isEmpty()) FloatArray(Bands.centers.size) else Curve.atCenters(all)
        val g = FloatArray(Bands.centers.size) { curve[it] + comp[it] }

        // Headroom automático: preamp = -(fracción del pico de ganancia).
        // El empuje del loudness inteligente cuenta a la mitad: son graves "de compensación",
        // no picos sostenidos de la música, y de lo demás se encarga el limitador.
        var peakBase = 0f
        for (v in curve) peakBase = max(peakBase, v)
        var peak = 0f
        for (v in g) peak = max(peak, v)
        val effectivePeak = peakBase + 0.5f * (peak - peakBase)
        val preamp = -s.headroom.coerceIn(0.3f, 1f) * effectivePeak

        // Level match por loudness percibido (ISO 226), limitado.
        val perceived = Psycho.perceivedGainDb(g)
        val match = (-(preamp + perceived)).coerceIn(0f, MAX_LEVEL_MATCH_DB)
        val post = min(match + s.extraDb, MAX_POST_GAIN_DB)
        val threshold = s.ceilingDb - post

        val engineGains = FloatArray(Bands.count)
        engineGains[0] = if (s.subsonic) Bands.SUBSONIC_CUT_DB else 0f
        for (i in g.indices) engineGains[i + 1] = g[i]

        val p = s.punch.coerceIn(0f, 1f)
        val mbc = List(Bands.MBC_COUNT) { i ->
            val b = base[i]
            val off = s.mbcOffsets.getOrElse(i) { 0f }
            MbcParams(
                thresholdDb = (b[0] + off).coerceIn(-60f, 0f),
                ratio = 1f + (b[1] - 1f) * p,
                attackMs = b[2],
                releaseMs = b[3],
                kneeDb = 6f,
                postGainDb = 1.0f * p
            )
        }

        return Rendered(
            bandGains = engineGains,
            inputGainDb = preamp,
            mbcEnabled = p > 0.02f,
            mbc = mbc,
            limiterThresholdDb = threshold,
            limiterPostGainDb = post,
            bassBoost = s.bassBoost,
            virtualizer = s.virtualizer,
            peakBoostDb = peak,
            levelMatchDb = match,
            loudnessCompDb = comp
        )
    }
}
