package com.eqforge.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.round

private fun snapTo(v: Float, step: Float): Float = if (step > 0f) round(v / step) * step else v

/** Slider horizontal propio. Solo consume movimiento horizontal (no pelea con el scroll). */
@Composable
fun HSlider(
    value: Float,
    onChange: (Float) -> Unit,
    min: Float,
    max: Float,
    modifier: Modifier = Modifier,
    color: Color = C.hot,
    step: Float = 0f,
    bipolar: Boolean = false
) {
    val cb by rememberUpdatedState(onChange)
    Canvas(
        modifier
            .fillMaxWidth()
            .height(34.dp)
            .pointerInput(min, max, step) {
                val pad = 12.dp.toPx()
                detectTapGestures { o ->
                    val t = ((o.x - pad) / (size.width - 2 * pad)).coerceIn(0f, 1f)
                    cb(snapTo(min + (max - min) * t, step))
                }
            }
            .pointerInput(min, max, step) {
                val pad = 12.dp.toPx()
                detectHorizontalDragGestures(
                    onDragStart = { o ->
                        val t = ((o.x - pad) / (size.width - 2 * pad)).coerceIn(0f, 1f)
                        cb(snapTo(min + (max - min) * t, step))
                    }
                ) { ch, _ ->
                    ch.consume()
                    val t = ((ch.position.x - pad) / (size.width - 2 * pad)).coerceIn(0f, 1f)
                    cb(snapTo(min + (max - min) * t, step))
                }
            }
    ) {
        val pad = 12.dp.toPx()
        val cy = size.height / 2f
        val x0 = pad
        val x1 = size.width - pad
        val t = ((value - min) / (max - min)).coerceIn(0f, 1f)
        val x = x0 + (x1 - x0) * t
        val gh = 6.dp.toPx()
        drawRoundRect(C.surface2, Offset(x0, cy - gh / 2), Size(x1 - x0, gh), CornerRadius(gh / 2))
        val from = if (bipolar) x0 + (x1 - x0) * ((0f - min) / (max - min)).coerceIn(0f, 1f) else x0
        val l = minOf(from, x)
        val r = maxOf(from, x)
        if (r - l > 0.5f) drawRoundRect(color, Offset(l, cy - gh / 2), Size(r - l, gh), CornerRadius(gh / 2))
        drawCircle(color.copy(alpha = 0.22f), 14.dp.toPx(), Offset(x, cy))
        drawCircle(C.text, 8.dp.toPx(), Offset(x, cy))
        drawCircle(color, 4.dp.toPx(), Offset(x, cy))
    }
}

/** Fader vertical bipolar (como una mesa de mezcla). Toca la etiqueta para volver a 0. */
@Composable
fun Fader(
    label: String,
    sub: String,
    value: Float,
    onChange: (Float) -> Unit,
    color: Color,
    modifier: Modifier = Modifier,
    range: Float = 6f
) {
    val cb by rememberUpdatedState(onChange)
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        T(fmtDb(value), 12, if (value == 0f) C.faint else color, FontWeight.Medium, align = TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        Canvas(
            Modifier
                .width(46.dp)
                .height(150.dp)
                .pointerInput(range) {
                    val pad = 16.dp.toPx()
                    detectTapGestures { o ->
                        cb(faderValue(o.y, size.height.toFloat(), pad, range))
                    }
                }
                .pointerInput(range) {
                    val pad = 16.dp.toPx()
                    detectVerticalDragGestures(
                        onDragStart = { o -> cb(faderValue(o.y, size.height.toFloat(), pad, range)) }
                    ) { ch, _ ->
                        ch.consume()
                        cb(faderValue(ch.position.y, size.height.toFloat(), pad, range))
                    }
                }
        ) {
            val pad = 16.dp.toPx()
            val cx = size.width / 2f
            val gw = 6.dp.toPx()
            val top = pad
            val bottom = size.height - pad
            val mid = (top + bottom) / 2f
            val y = mid - (value / range) * (bottom - top) / 2f
            drawRoundRect(C.surface2, Offset(cx - gw / 2, top), Size(gw, bottom - top), CornerRadius(gw / 2))
            // marcas de ±
            for (i in -3..3) {
                val ty = mid - (i / 3f) * (bottom - top) / 2f
                val tw = if (i == 0) 11.dp.toPx() else 6.dp.toPx()
                drawLine(C.line, Offset(cx - tw - 8.dp.toPx(), ty), Offset(cx - 8.dp.toPx(), ty), 1.dp.toPx())
                drawLine(C.line, Offset(cx + 8.dp.toPx(), ty), Offset(cx + tw + 8.dp.toPx(), ty), 1.dp.toPx())
            }
            val l = minOf(y, mid)
            val h = abs(y - mid)
            if (h > 0.5f) {
                drawRoundRect(
                    Brush.verticalGradient(listOf(color, color.copy(alpha = 0.45f)), startY = l, endY = l + h),
                    Offset(cx - gw / 2, l), Size(gw, h), CornerRadius(gw / 2)
                )
            }
            val tw = 36.dp.toPx()
            val th = 18.dp.toPx()
            drawRoundRect(color.copy(alpha = 0.25f), Offset(cx - tw / 2 - 3.dp.toPx(), y - th / 2 - 3.dp.toPx()), Size(tw + 6.dp.toPx(), th + 6.dp.toPx()), CornerRadius(10.dp.toPx()))
            drawRoundRect(C.text, Offset(cx - tw / 2, y - th / 2), Size(tw, th), CornerRadius(7.dp.toPx()))
            drawRoundRect(color, Offset(cx - tw / 2 + 6.dp.toPx(), y - 1.5.dp.toPx()), Size(tw - 12.dp.toPx(), 3.dp.toPx()), CornerRadius(1.5.dp.toPx()))
        }
        Spacer(Modifier.height(6.dp))
        T(label, 13, C.text, FontWeight.Medium, modifier = Modifier.tap { cb(0f) }, align = TextAlign.Center)
        T(sub, 10, C.faint, align = TextAlign.Center)
    }
}

private fun faderValue(y: Float, h: Float, pad: Float, range: Float): Float {
    val t = 1f - ((y - pad) / (h - 2 * pad)).coerceIn(0f, 1f)
    val v = (t * 2f - 1f) * range
    return if (abs(v) < 0.3f) 0f else round(v * 4f) / 4f
}

@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(C.bg)
            .border(1.dp, C.line, shape)
            .padding(3.dp)
    ) {
        options.forEachIndexed { i, o ->
            val sel = i == selected
            val bg by animateColorAsState(if (sel) C.hot else Color.Transparent, tween(180), label = "seg")
            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(11.dp))
                    .background(bg)
                    .tap { onSelect(i) }
                    .padding(vertical = 9.dp),
                contentAlignment = Alignment.Center
            ) {
                T(o, 13, if (sel) Color.White else C.dim, FontWeight.Medium, align = TextAlign.Center)
            }
        }
    }
}

@Composable
fun Toggle(on: Boolean, onChange: (Boolean) -> Unit) {
    val x by animateFloatAsState(if (on) 1f else 0f, tween(160), label = "toggle")
    Box(
        Modifier
            .width(48.dp)
            .height(28.dp)
            .clip(CircleShape)
            .background(lerp(C.line, C.hot, x))
            .tap { onChange(!on) }
    ) {
        Box(
            Modifier
                .padding(3.dp)
                .offset(x = 20.dp * x)
                .size(22.dp)
                .clip(CircleShape)
                .background(Color.White)
        )
    }
}

@Composable
fun PowerButton(on: Boolean, onClick: () -> Unit) {
    val glow by animateFloatAsState(if (on) 1f else 0f, tween(300), label = "power")
    Canvas(Modifier.size(58.dp).tap(onClick)) {
        val c = center
        val r = size.minDimension / 2f - 7.dp.toPx()
        if (glow > 0.01f) {
            drawCircle(C.hot.copy(alpha = 0.10f * glow), r + 7.dp.toPx(), c)
            drawCircle(C.hot.copy(alpha = 0.20f * glow), r + 3.dp.toPx(), c)
        }
        drawCircle(lerp(C.surface2, C.hot, glow), r, c)
        val gc = lerp(C.dim, Color.White, glow)
        val ar = r * 0.48f
        drawArc(
            gc, -55f, 290f, false,
            Offset(c.x - ar, c.y - ar), Size(ar * 2, ar * 2),
            style = Stroke(2.6.dp.toPx(), cap = StrokeCap.Round)
        )
        drawLine(gc, Offset(c.x, c.y - ar * 1.05f), Offset(c.x, c.y - ar * 0.1f), 2.6.dp.toPx(), StrokeCap.Round)
    }
}

@Composable
fun Pill(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    filled: Boolean = false,
    color: Color = C.hot
) {
    val shape = RoundedCornerShape(50)
    Box(
        modifier
            .clip(shape)
            .then(if (filled) Modifier.background(color) else Modifier.border(1.dp, C.line, shape))
            .tap(onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        T(text, 13, if (filled) Color.White else C.text, FontWeight.Medium, align = TextAlign.Center)
    }
}

/** Botón que repite mientras lo mantienes (para ajustar freq/ganancia/Q al milímetro). */
@Composable
fun RepeatButton(label: String, onStep: () -> Unit, modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    val step by rememberUpdatedState(onStep)
    Box(
        modifier
            .size(34.dp)
            .clip(CircleShape)
            .background(C.surface2)
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    step()
                    val job = scope.launch {
                        delay(380)
                        while (true) {
                            step()
                            delay(55)
                        }
                    }
                    tryAwaitRelease()
                    job.cancel()
                })
            },
        contentAlignment = Alignment.Center
    ) {
        T(label, 18, C.text, FontWeight.Medium, align = TextAlign.Center)
    }
}

@Composable
fun Section(title: String, modifier: Modifier = Modifier, trailing: String? = null, onTrailing: () -> Unit = {}) {
    Row(
        modifier.fillMaxWidth().padding(horizontal = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        T(title, 20, C.text, font = Cond)
        if (trailing != null) T(trailing, 13, C.hot, FontWeight.Medium, modifier = Modifier.tap(onTrailing))
    }
}

@Composable
fun MiniCurve(samples: FloatArray, modifier: Modifier = Modifier, range: Float = 7f, alpha: Float = 1f) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        drawLine(C.line, Offset(0f, h / 2f), Offset(w, h / 2f), 1.dp.toPx())
        val path = Path()
        samples.forEachIndexed { i, v ->
            val x = w * i / (samples.size - 1f)
            val y = h / 2f - (v.coerceIn(-range, range) / range) * (h / 2f - 3.dp.toPx())
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(
            path, Brush.horizontalGradient(*RAMP, startX = 0f, endX = w), alpha = alpha,
            style = Stroke(2.2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }
}

/** Iconos de la barra inferior dibujados a mano: 0 = sonido, 1 = presets, 2 = laboratorio, 3 = juego. */
@Composable
fun NavIcon(kind: Int, color: Color, modifier: Modifier = Modifier.size(24.dp)) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val sw = 2.dp.toPx()
        when (kind) {
            0 -> for (i in 0..2) {
                val x = w * (0.2f + 0.3f * i)
                drawLine(color, Offset(x, h * 0.14f), Offset(x, h * 0.86f), sw, StrokeCap.Round)
                val y = h * listOf(0.62f, 0.34f, 0.5f)[i]
                drawCircle(C.bg, 4.2.dp.toPx(), Offset(x, y))
                drawCircle(color, 3.4.dp.toPx(), Offset(x, y), style = Stroke(sw))
            }
            1 -> for (r in 0..1) for (c in 0..1) {
                drawRoundRect(
                    color, Offset(w * (0.12f + 0.45f * c), h * (0.12f + 0.45f * r)), Size(w * 0.31f, h * 0.31f),
                    CornerRadius(3.dp.toPx()), style = Stroke(sw)
                )
            }
            3 -> {
                // Control de juego: cuerpo redondeado, cruz a la izquierda, botón a la derecha.
                drawRoundRect(color, Offset(w * 0.06f, h * 0.28f), Size(w * 0.88f, h * 0.46f), CornerRadius(8.dp.toPx()), style = Stroke(sw))
                drawLine(color, Offset(w * 0.28f, h * 0.41f), Offset(w * 0.28f, h * 0.61f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * 0.18f, h * 0.51f), Offset(w * 0.38f, h * 0.51f), sw, StrokeCap.Round)
                drawCircle(color, 2.2.dp.toPx(), Offset(w * 0.68f, h * 0.51f))
            }
            else -> {
                drawArc(color, 150f, 240f, false, Offset(w * 0.1f, h * 0.14f), Size(w * 0.8f, h * 0.8f), style = Stroke(sw, cap = StrokeCap.Round))
                drawLine(color, Offset(w * 0.5f, h * 0.54f), Offset(w * 0.72f, h * 0.3f), sw, StrokeCap.Round)
                drawCircle(color, 2.dp.toPx(), Offset(w * 0.5f, h * 0.54f))
            }
        }
    }
}
