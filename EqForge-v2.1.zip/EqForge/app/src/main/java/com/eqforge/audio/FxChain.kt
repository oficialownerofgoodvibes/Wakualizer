package com.eqforge.audio

import android.media.audiofx.BassBoost
import android.media.audiofx.DynamicsProcessing
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import android.os.SystemClock
import android.util.Log
import kotlin.math.roundToInt

/**
 * Cadena de efectos sobre UNA sesión de audio (0 = mezcla global, o la sesión
 * que anuncia Spotify / YT Music).
 *
 * Motor principal: DynamicsProcessing = Pre-EQ de 30 bandas + compresor
 * multibanda de 4 + limitador + ganancia de entrada (preamp), todo software
 * del framework. Si el equipo no lo implementa, cae al Equalizer de hardware.
 *
 * Regla de oro (doc de Android): una banda con enabled=false queda MUTEADA,
 * así que jamás se deshabilitan bandas; se usa ganancia 0.
 */
class FxChain(val sessionId: Int, val pkg: String?) {

    private companion object {
        const val TAG = "FxChain"
        const val RETRY_MS = 4000L
    }

    private var dp: DynamicsProcessing? = null
    private var hwEq: Equalizer? = null
    private var bass: BassBoost? = null
    private var virt: Virtualizer? = null
    private var lastTry = 0L

    @Volatile var alive: Boolean = false
        private set
    @Volatile var error: String? = null
        private set
    @Volatile var backend: String = "—"
        private set

    /** Crea el efecto si no existe (con reintento espaciado). */
    fun ensure(): Boolean {
        if (alive) return true
        val now = SystemClock.elapsedRealtime()
        if (lastTry != 0L && now - lastTry < RETRY_MS) return false
        lastTry = now
        release()

        try {
            val cfg = DynamicsProcessing.Config.Builder(
                DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
                2,
                true, Bands.count,
                true, Bands.MBC_COUNT,
                false, 0,
                true
            ).build()
            dp = DynamicsProcessing(0, sessionId, cfg)
            backend = "DynamicsProcessing · ${Bands.count} bandas"
            error = null
            alive = true
            return true
        } catch (e: Throwable) {
            error = e.message ?: e.javaClass.simpleName
            Log.w(TAG, "DynamicsProcessing falló en sesión $sessionId: $error")
        }

        try {
            val eq = Equalizer(0, sessionId)
            hwEq = eq
            backend = "Equalizer HW · ${eq.numberOfBands.toInt()} bandas"
            alive = true
            return true
        } catch (e: Throwable) {
            error = e.message ?: e.javaClass.simpleName
            Log.w(TAG, "Equalizer HW también falló en sesión $sessionId: $error")
        }
        return false
    }

    /** [gainDb]: ganancia extra solo de esta sesión (volumen propio de Spotify en Modo Juego). */
    fun apply(r: Rendered, active: Boolean, gainDb: Float = 0f) {
        if (!ensure()) return
        try {
            dp?.let { writeDp(it, r, active, gainDb) }
            hwEq?.let { writeHw(it, r, active, gainDb) }
            writeExtras(r, active)
        } catch (e: Throwable) {
            // El audioserver se reinició o el efecto quedó inválido: se recrea en el siguiente ciclo.
            error = e.message ?: e.javaClass.simpleName
            Log.w(TAG, "apply falló (sesión $sessionId): $error")
            release()
        }
    }

    private fun writeDp(d: DynamicsProcessing, r: Rendered, active: Boolean, gainDb: Float) {
        // Con el EQ apagado pero con volumen propio activo, el efecto sigue vivo en plano
        // (bandas a 0 dB, sin compresor ni limitador) solo para aplicar la ganancia.
        val gainOnly = !active && gainDb != 0f
        d.setEnabled(active || gainOnly)
        if (!active && !gainOnly) return

        d.setInputGainAllChannelsTo((if (active) r.inputGainDb else 0f) + gainDb)

        val n = Bands.count
        val eq = DynamicsProcessing.Eq(true, true, n)
        for (i in 0 until n) {
            eq.setBand(i, DynamicsProcessing.EqBand(true, Bands.cutoffs[i], if (active) r.bandGains[i] else 0f))
        }
        d.setPreEqAllChannelsTo(eq)

        val mbc = DynamicsProcessing.Mbc(true, active && r.mbcEnabled, Bands.MBC_COUNT)
        for (i in 0 until Bands.MBC_COUNT) {
            val m = r.mbc[i]
            mbc.setBand(
                i,
                DynamicsProcessing.MbcBand(
                    true, Bands.mbcCutoffs[i], m.attackMs, m.releaseMs, m.ratio,
                    m.thresholdDb, m.kneeDb, -90f, 1f, 0f, m.postGainDb
                )
            )
        }
        d.setMbcAllChannelsTo(mbc)

        d.setLimiterAllChannelsTo(
            DynamicsProcessing.Limiter(
                true, active, 0,
                Renderer.LIMITER_ATTACK_MS, Renderer.LIMITER_RELEASE_MS, Renderer.LIMITER_RATIO,
                if (active) r.limiterThresholdDb else 0f, if (active) r.limiterPostGainDb else 0f
            )
        )
    }

    private fun writeHw(eq: Equalizer, r: Rendered, active: Boolean, gainDb: Float) {
        // El Equalizer de hardware solo llega a unos -15 dB por banda: el volumen propio
        // queda limitado a ese rango si el teléfono no soporta DynamicsProcessing.
        val on = active || gainDb != 0f
        eq.setEnabled(on)
        if (!on) return
        val range = eq.bandLevelRange
        val lo = range[0].toInt()
        val hi = range[1].toInt()
        val centerGains = FloatArray(Bands.centers.size) { r.bandGains[it + 1] }
        for (b in 0 until eq.numberOfBands.toInt()) {
            val hz = eq.getCenterFreq(b.toShort()) / 1000f
            val base = if (active) Bands.interpolate(centerGains, hz) + r.inputGainDb else 0f
            eq.setBandLevel(b.toShort(), ((base + gainDb) * 100f).roundToInt().coerceIn(lo, hi).toShort())
        }
    }

    private fun writeExtras(r: Rendered, active: Boolean) {
        if (r.bassBoost > 0 && bass == null) {
            try { bass = BassBoost(0, sessionId) } catch (e: Throwable) { Log.w(TAG, "BassBoost no disponible") }
        }
        bass?.let {
            it.setEnabled(active && r.bassBoost > 0)
            if (it.strengthSupported) it.setStrength(r.bassBoost.coerceIn(0, 1000).toShort())
        }
        if (r.virtualizer > 0 && virt == null) {
            try { virt = Virtualizer(0, sessionId) } catch (e: Throwable) { Log.w(TAG, "Virtualizer no disponible") }
        }
        virt?.let {
            it.setEnabled(active && r.virtualizer > 0)
            if (it.strengthSupported) it.setStrength(r.virtualizer.coerceIn(0, 1000).toShort())
        }
    }

    fun release() {
        try { dp?.setEnabled(false) } catch (e: Throwable) { }
        try { dp?.release() } catch (e: Throwable) { }
        try { hwEq?.release() } catch (e: Throwable) { }
        try { bass?.release() } catch (e: Throwable) { }
        try { virt?.release() } catch (e: Throwable) { }
        dp = null; hwEq = null; bass = null; virt = null
        alive = false
    }
}
