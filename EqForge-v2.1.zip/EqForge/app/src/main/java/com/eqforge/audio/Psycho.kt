package com.eqforge.audio

import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.min
import kotlin.math.pow

/**
 * Psicoacústica sobre ISO 226:2003 (tablas verificadas contra la implementación
 * de referencia de Tackett).
 *
 * 1) Loudness inteligente: el oído pierde graves y aire cuando escuchas bajito
 *    (curvas de Fletcher-Munson). Estimamos el nivel de escucha con el volumen
 *    del sistema y compensamos la diferencia entre ese contorno y el de
 *    referencia.
 * 2) Level match: pesa la ganancia de cada banda según la sensibilidad del
 *    oído (a 70 phon) para igualar el volumen PERCIBIDO del EQ contra el audio
 *    sin procesar. Sin esto, "más fuerte" siempre suena "mejor" y el A/B miente.
 */
object Psycho {
    private val F = floatArrayOf(20f, 25f, 31.5f, 40f, 50f, 63f, 80f, 100f, 125f, 160f, 200f, 250f, 315f, 400f, 500f, 630f, 800f,
        1000f, 1250f, 1600f, 2000f, 2500f, 3150f, 4000f, 5000f, 6300f, 8000f, 10000f, 12500f)
    private val AF = doubleArrayOf(0.532, 0.506, 0.480, 0.455, 0.432, 0.409, 0.387, 0.367, 0.349, 0.330, 0.315, 0.301, 0.288, 0.276,
        0.267, 0.259, 0.253, 0.250, 0.246, 0.244, 0.243, 0.243, 0.243, 0.242, 0.242, 0.245, 0.254, 0.271, 0.301)
    private val LU = doubleArrayOf(-31.6, -27.2, -23.0, -19.1, -15.9, -13.0, -10.3, -8.1, -6.2, -4.5, -3.1, -2.0, -1.1, -0.4, 0.0,
        0.3, 0.5, 0.0, -2.7, -4.1, -1.0, 1.7, 2.5, 1.2, -2.1, -7.1, -11.2, -10.7, -3.1)
    private val TF = doubleArrayOf(78.5, 68.7, 59.5, 51.1, 44.0, 37.5, 31.5, 26.5, 22.1, 17.9, 14.4, 11.4, 8.6, 6.2, 4.4, 3.0, 2.2,
        2.4, 3.5, 1.7, -1.3, -4.2, -6.0, -5.4, -1.5, 6.0, 12.6, 13.9, 12.3)

    private val logF = DoubleArray(F.size) { ln(F[it].toDouble()) }

    // Estimación del nivel de escucha a partir del volumen (0..1): 30 phon .. 80 phon.
    private const val LISTEN_MIN_PHON = 30.0
    private const val LISTEN_SPAN_PHON = 50.0
    private const val REF_PHON = 72.0
    private const val LF_CAP_DB = 5.5f
    private const val HF_CAP_DB = 2.5f

    /** SPL requerido menos phon (0 en 1 kHz), interpolado en log-frecuencia. */
    private fun shape(phon: Double, hz: Float): Double {
        val x = ln(hz.toDouble())
        val s = DoubleArray(F.size) { i ->
            val bigA = 4.47e-3 * (10.0.pow(0.025 * phon) - 1.15) + (0.4 * 10.0.pow((TF[i] + LU[i]) / 10.0 - 9.0)).pow(AF[i])
            (10.0 / AF[i]) * log10(bigA) - LU[i] + 94.0 - phon
        }
        if (x <= logF.first()) return s.first()
        if (x >= logF.last()) return s.last()
        var i = 0
        while (i < F.size - 2 && logF[i + 1] < x) i++
        val t = (x - logF[i]) / (logF[i + 1] - logF[i])
        return s[i] + (s[i + 1] - s[i]) * t
    }

    /** Nivel de escucha estimado (phon) para un volumen 0..1. */
    fun listenPhon(volume: Float): Float = (LISTEN_MIN_PHON + LISTEN_SPAN_PHON * volume.coerceIn(0f, 1f)).toFloat()

    /**
     * Compensación (dB, >= 0) en cada centro de banda para ese volumen.
     * [strength] 0..1 escala el efecto; hay topes para no inflar graves ni brillo.
     */
    fun loudnessComp(volume: Float, strength: Float): FloatArray {
        val listen = LISTEN_MIN_PHON + LISTEN_SPAN_PHON * volume.coerceIn(0f, 1f)
        return FloatArray(Bands.centers.size) { i ->
            val hz = Bands.centers[i]
            val raw = (shape(listen, hz) - shape(REF_PHON, hz)) * strength
            val cap = when {
                hz <= 100f -> LF_CAP_DB
                hz >= 8000f -> HF_CAP_DB
                else -> 99f
            }
            min(raw.toFloat(), cap).coerceAtLeast(0f)
        }
    }

    private val weights: DoubleArray by lazy {
        DoubleArray(Bands.centers.size) { i -> 10.0.pow(-shape(70.0, Bands.centers[i]) / 10.0) }
    }

    /** Cambio de volumen percibido (dB) de una curva definida en [Bands.centers]. */
    fun perceivedGainDb(gains: FloatArray): Float {
        var num = 0.0
        var den = 0.0
        for (i in gains.indices) {
            num += weights[i] * 10.0.pow(gains[i] / 10.0)
            den += weights[i]
        }
        return (10.0 * log10(num / den)).toFloat()
    }
}
