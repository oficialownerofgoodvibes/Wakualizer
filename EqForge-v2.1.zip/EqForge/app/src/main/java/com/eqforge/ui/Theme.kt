package com.eqforge.ui

import android.graphics.Typeface
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.eqforge.audio.Bands
import java.util.Locale

/**
 * Identidad visual: noche ultravioleta + una rampa "calor -> hielo" que ES el
 * eje de frecuencias (graves rosa-rojo, medios ámbar, agudos cian y violeta).
 * El color nunca decora: te dice en qué parte del espectro estás.
 */
object C {
    val bg = Color(0xFF0E0B26)
    val surface = Color(0xFF181442)
    val surface2 = Color(0xFF221D58)
    val line = Color(0xFF343072)
    val text = Color(0xFFF4F1FF)
    val dim = Color(0xFFA19BD6)
    val faint = Color(0xFF6C66A8)
    val hot = Color(0xFFFF4D7E)
    val ice = Color(0xFF6EE7F0)
}

val RAMP: Array<Pair<Float, Color>> = arrayOf(
    0.00f to Color(0xFFFF3D77),
    0.22f to Color(0xFFFF7A3D),
    0.42f to Color(0xFFFFC247),
    0.58f to Color(0xFFFFE9A8),
    0.76f to Color(0xFF6EE7F0),
    0.90f to Color(0xFF8F8CFF),
    1.00f to Color(0xFFC58BFF)
)

fun rampColor(t: Float): Color {
    val x = t.coerceIn(0f, 1f)
    for (i in 1 until RAMP.size) {
        if (x <= RAMP[i].first) {
            val a = RAMP[i - 1]
            val b = RAMP[i]
            return lerp(a.second, b.second, (x - a.first) / (b.first - a.first))
        }
    }
    return RAMP.last().second
}

fun hzColor(hz: Float): Color = rampColor(Bands.hzToT(hz))

fun rampWithAlpha(alpha: Float): Array<Pair<Float, Color>> =
    Array(RAMP.size) { RAMP[it].first to RAMP[it].second.copy(alpha = alpha) }

val Cond: FontFamily = FontFamily(Typeface.create("sans-serif-condensed", Typeface.BOLD))
val Body: FontFamily = FontFamily.SansSerif

/** Texto con números tabulares (nada salta mientras arrastras un valor). */
@Composable
fun T(
    text: String,
    size: Int = 14,
    color: Color = C.text,
    weight: FontWeight = FontWeight.Normal,
    font: FontFamily = Body,
    modifier: Modifier = Modifier,
    align: TextAlign = TextAlign.Start,
    maxLines: Int = 1,
    spacing: Float = 0f
) {
    BasicText(
        text = text,
        modifier = modifier,
        style = TextStyle(
            color = color,
            fontSize = size.sp,
            fontWeight = weight,
            fontFamily = font,
            textAlign = align,
            letterSpacing = spacing.sp,
            fontFeatureSettings = "tnum"
        ),
        overflow = TextOverflow.Ellipsis,
        maxLines = maxLines
    )
}

/** Click sin ripple ni overlay de depuración. */
fun Modifier.tap(onClick: () -> Unit): Modifier = composed {
    clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = null,
        onClick = onClick
    )
}

fun Modifier.card(radius: Int = 22): Modifier {
    val shape = RoundedCornerShape(radius.dp)
    return this.clip(shape).background(C.surface).border(1.dp, C.line, shape)
}

fun fmtDb(v: Float, decimals: Int = 1): String {
    val s = String.format(Locale.US, "%." + decimals + "f", v)
    return if (v > 0.0001f) "+$s" else s
}

fun fmtHz(hz: Float): String {
    if (hz < 1000f) return String.format(Locale.US, "%.0f Hz", hz)
    val s = String.format(Locale.US, "%.2f", hz / 1000f).trimEnd('0').trimEnd('.')
    return "$s kHz"
}
