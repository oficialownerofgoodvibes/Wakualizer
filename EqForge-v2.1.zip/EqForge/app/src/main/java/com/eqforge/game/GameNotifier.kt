package com.eqforge.game

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.eqforge.R
import com.eqforge.service.DspService
import com.eqforge.ui.MainActivity
import kotlin.math.roundToInt

/** Notificación "juego detectado": tocarla abre la barra de Spotify; tiene botones − / +. */
object GameNotifier {
    private const val CHANNEL = "eqforge_game"
    private const val ID = 2001

    fun post(ctx: Context, label: String, musicVolume: Float) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Modo Juego", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Aviso cuando abres un juego vigilado"
                setShowBadge(false)
            }
        )
        val pct = (musicVolume * 100).roundToInt()
        val overlayOk = Perms.canOverlay(ctx)

        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val content = if (overlayOk) {
            PendingIntent.getService(ctx, 10, Intent(ctx, DspService::class.java).setAction(DspService.ACTION_SHOW_PANEL), flags)
        } else {
            // Sin permiso de superposición no hay barra flotante: lleva a la pestaña Juego.
            PendingIntent.getActivity(
                ctx, 11,
                Intent(ctx, MainActivity::class.java).putExtra(MainActivity.EXTRA_OPEN_GAME, true)
                    .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                flags
            )
        }
        fun act(code: Int, action: String) =
            PendingIntent.getService(ctx, code, Intent(ctx, DspService::class.java).setAction(action), flags)

        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_equalizer)
            .setContentTitle("$label detectado")
            .setContentText(
                if (overlayOk) "Spotify al $pct % · toca para ajustar la barra"
                else "Spotify al $pct % · toca para dar permiso de barra flotante"
            )
            .setContentIntent(content)
            .addAction(0, "− Música", act(12, DspService.ACTION_MUSIC_DOWN))
            .addAction(0, "+ Música", act(13, DspService.ACTION_MUSIC_UP))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .build()
        nm.notify(ID, n)
    }

    fun cancel(ctx: Context) {
        ctx.getSystemService(NotificationManager::class.java).cancel(ID)
    }
}
