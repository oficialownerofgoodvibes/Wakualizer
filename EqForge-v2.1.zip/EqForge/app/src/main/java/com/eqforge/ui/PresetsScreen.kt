package com.eqforge.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.eqforge.audio.Cat
import com.eqforge.audio.Forge
import com.eqforge.audio.Preset
import com.eqforge.audio.Presets

@Composable
fun PresetsScreen() {
    val st by Forge.state.collectAsState()
    val user by Forge.userPresets.collectAsState()
    var cat by remember { mutableStateOf("Todos") }
    var showSave by remember { mutableStateOf(false) }
    var showImport by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<Preset?>(null) }

    val all = Presets.builtIn + user
    val shown = if (cat == "Todos") all else all.filter { it.category == cat }

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column {
                T("Presets", 30, C.text, font = Cond)
                T("${all.size} sonidos · mantén pulsado uno tuyo para borrarlo", 13, C.dim)
            }
        }
        item(span = { GridItemSpan(maxLineSpan) }) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf("Todos") + Cat.all) { c ->
                    val sel = c == cat
                    val shape = RoundedCornerShape(50)
                    Box(
                        Modifier
                            .clip(shape)
                            .background(if (sel) C.hot else C.surface)
                            .border(1.dp, if (sel) C.hot else C.line, shape)
                            .tap { cat = c }
                            .padding(horizontal = 16.dp, vertical = 9.dp)
                    ) { T(c, 13, if (sel) Color.White else C.dim, FontWeight.Medium) }
                }
            }
        }
        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Pill("Guardar actual", { showSave = true }, Modifier.weight(1f), filled = true)
                Pill("Importar AutoEq", { showImport = true }, Modifier.weight(1f))
            }
        }
        items(shown, key = { it.id }) { p ->
            PresetCard(
                p, p.id == st.presetId, { Forge.selectPreset(p.id) }, Modifier.fillMaxWidth(),
                onLongPress = if (!p.builtIn) ({ toDelete = p }) else null
            )
        }
    }

    if (showSave) {
        TextDialog(
            title = "Guardar sonido actual",
            hint = "Nombre del preset",
            initial = "",
            confirm = "Guardar",
            onDismiss = { showSave = false },
            onOk = { Forge.saveCurrentAs(it); showSave = false }
        )
    }
    if (showImport) ImportDialog { showImport = false }
    toDelete?.let { p ->
        ConfirmDialog(
            "¿Borrar «${p.name}»?", "Borrar",
            onDismiss = { toDelete = null },
            onOk = { Forge.deleteUserPreset(p.id); toDelete = null }
        )
    }
}

@Composable
private fun DialogSurface(content: @Composable () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(26.dp))
            .background(C.surface)
            .border(1.dp, C.line, RoundedCornerShape(26.dp))
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) { content() }
}

@Composable
fun TextDialog(title: String, hint: String, initial: String, confirm: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    Dialog(onDismissRequest = onDismiss) {
        DialogSurface {
            T(title, 22, C.text, font = Cond)
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(C.bg)
                    .border(1.dp, C.line, RoundedCornerShape(14.dp)).padding(14.dp)
            ) {
                if (text.isEmpty()) T(hint, 16, C.faint)
                BasicTextField(
                    value = text,
                    onValueChange = { text = it.take(32) },
                    singleLine = true,
                    textStyle = TextStyle(color = C.text, fontSize = 16.sp),
                    cursorBrush = SolidColor(C.hot),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Pill("Cancelar", onDismiss, Modifier.weight(1f))
                Pill(confirm, { onOk(text) }, Modifier.weight(1f), filled = true)
            }
        }
    }
}

@Composable
fun ConfirmDialog(message: String, confirm: String, onDismiss: () -> Unit, onOk: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        DialogSurface {
            T(message, 20, C.text, font = Cond, maxLines = 3)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Pill("Cancelar", onDismiss, Modifier.weight(1f))
                Pill(confirm, onOk, Modifier.weight(1f), filled = true)
            }
        }
    }
}

@Composable
private fun ImportDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var msg by remember { mutableStateOf<String?>(null) }

    fun doImport(text: String?, name: String) {
        val n = if (text.isNullOrBlank()) 0 else Forge.importAutoEq(text, name)
        if (n > 0) onDismiss() else msg = "No encontré filtros válidos (PK / LSC / HSC)."
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            val text = try {
                ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            } catch (e: Exception) { null }
            doImport(text, "AutoEq")
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        DialogSurface {
            T("Importar perfil AutoEq", 22, C.text, font = Cond)
            T(
                "Copia el contenido de un ParametricEQ.txt (autoeq.app) y pégalo, o elige el archivo. Cada filtro entra tal cual, con su frecuencia, ganancia y Q exactas.",
                13, C.dim, maxLines = 6
            )
            Pill("Pegar del portapapeles", { doImport(clipboard.getText()?.text, "AutoEq") }, Modifier.fillMaxWidth(), filled = true)
            Pill("Elegir archivo .txt", { picker.launch(arrayOf("text/*", "application/octet-stream")) }, Modifier.fillMaxWidth())
            msg?.let { T(it, 13, C.hot, maxLines = 2) }
            Spacer(Modifier.height(2.dp))
            Pill("Cerrar", onDismiss, Modifier.fillMaxWidth())
        }
    }
}
