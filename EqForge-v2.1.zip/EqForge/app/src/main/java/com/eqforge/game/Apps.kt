package com.eqforge.game

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap

data class AppEntry(val pkg: String, val label: String, val suggested: Boolean)

/** Escaneo de apps instaladas (solo las que tienen icono en el lanzador). */
object Apps {
    val KNOWN_GAMES: Map<String, String> = linkedMapOf(
        "com.dts.freefireth" to "Free Fire",
        "com.dts.freefiremax" to "Free Fire MAX",
        "com.tencent.ig" to "PUBG Mobile",
        "com.pubg.imobile" to "BGMI",
        "com.activision.callofduty.shooter" to "Call of Duty Mobile",
        "com.axlebolt.standoff2" to "Standoff 2",
        "com.criticalforceentertainment.criticalops" to "Critical Ops",
        "com.proximabeta.mf.uamo" to "Arena Breakout",
        "com.mobile.legends" to "Mobile Legends",
        "com.supercell.brawlstars" to "Brawl Stars",
        "com.riotgames.league.wildrift" to "Wild Rift"
    )

    val SPOTIFY: Set<String> = setOf("com.spotify.music", "com.spotify.lite")

    fun launchable(ctx: Context): List<AppEntry> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val infos = if (Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION") pm.queryIntentActivities(intent, 0)
        }
        return infos
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != ctx.packageName }
            .distinctBy { it.first }
            .map { (pkg, label) -> AppEntry(pkg, label, pkg in KNOWN_GAMES) }
            .sortedWith(compareByDescending<AppEntry> { it.suggested }.thenBy { it.label.lowercase() })
    }

    fun installedKnownGames(ctx: Context): Set<String> =
        launchable(ctx).filter { it.suggested }.map { it.pkg }.toSet()

    fun isInstalled(ctx: Context, pkg: String): Boolean = try {
        ctx.packageManager.getPackageInfo(pkg, 0); true
    } catch (e: Exception) { false }

    fun spotifyInstalled(ctx: Context): Boolean = SPOTIFY.any { isInstalled(ctx, it) }

    fun label(ctx: Context, pkg: String): String =
        KNOWN_GAMES[pkg] ?: try {
            val pm = ctx.packageManager
            pm.getApplicationInfo(pkg, 0).loadLabel(pm).toString()
        } catch (e: Exception) { pkg.substringAfterLast('.') }

    fun icon(ctx: Context, pkg: String): ImageBitmap? = try {
        ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap()
    } catch (e: Throwable) { null }
}
