package com.eqforge.audio

import android.app.Application
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import com.eqforge.game.Apps
import com.eqforge.game.GameSettings
import com.eqforge.game.GameState
import com.eqforge.game.GameTuning
import com.eqforge.game.Mix
import kotlin.math.abs

/**
 * Hub único de estado. Todo (UI, servicio, tile, detector de salida) pasa por
 * aquí, siempre desde el hilo principal. El motor recibe el estado ya
 * renderizado y lo aplica en su propio hilo.
 */
object Forge {
    private var inited = false
    lateinit var app: Application
        private set
    lateinit var engine: Engine
        private set
    private lateinit var store: Store
    private val main = Handler(Looper.getMainLooper())

    val state = MutableStateFlow(SoundState())
    val userPresets = MutableStateFlow<List<Preset>>(emptyList())
    val status = MutableStateFlow(EngineStatus())
    val volume = MutableStateFlow(0.5f)
    val abHold = MutableStateFlow(false)
    val device = MutableStateFlow<DeviceInfo?>(null)
    val rendered = MutableStateFlow<Rendered?>(null)
    val gameSettings = MutableStateFlow(GameSettings())
    val game = MutableStateFlow(GameState())
    /** Sube cada vez que la app vuelve a primer plano: la UI re-lee los permisos. */
    val permTick = MutableStateFlow(0)

    fun init(application: Application) {
        if (inited) return
        inited = true
        app = application
        store = Store(application)
        state.value = store.loadState()
        userPresets.value = store.loadUserPresets()
        // Primera vez: vigila solo los juegos conocidos que ya tengas instalados (Free Fire, etc.).
        gameSettings.value = store.loadGame()
            ?: GameSettings(watched = Apps.installedKnownGames(application)).also { store.saveGame(it) }
        engine = Engine { st -> status.value = st }
        push()
    }

    // ---------------------------------------------------------------- núcleo

    private fun push() {
        val s = state.value
        val r = Renderer.render(s, volume.value)
        rendered.value = r
        val g = game.value
        val gs = gameSettings.value
        val mix = if (g.active) {
            // Música (Spotify): tu EQ + hueco para pasos, y su propio volumen. El juego no se toca.
            val music = if (gs.carve && s.enabled) {
                Renderer.render(s.copy(filters = s.filters + GameTuning.carve(gs.carveStrength)), volume.value)
            } else null
            Mix(music, GameTuning.volumeToDb(gs.musicVolume))
        } else Mix.NONE
        engine.submit(r, s.enabled && !abHold.value, s.capture, mix)
    }

    private val persist = Runnable { store.saveState(state.value) }

    fun update(t: (SoundState) -> SoundState) {
        state.update(t)
        push()
        main.removeCallbacks(persist)
        main.postDelayed(persist, 500)
    }

    // ------------------------------------------------------------- Modo Juego

    private val persistGame = Runnable { store.saveGame(gameSettings.value) }

    fun updateGame(t: (GameSettings) -> GameSettings) {
        gameSettings.update(t)
        push()
        main.removeCallbacks(persistGame)
        main.postDelayed(persistGame, 500)
    }

    fun setMusicVolume(v: Float) {
        val c = v.coerceIn(0f, 1f)
        if (abs(c - gameSettings.value.musicVolume) < 0.004f) return
        updateGame { it.copy(musicVolume = c) }
    }

    fun nudgeMusic(delta: Float) {
        val v = (Math.round((gameSettings.value.musicVolume + delta) * 20f) / 20f)
        setMusicVolume(v)
    }

    fun enterGame(pkg: String) {
        game.value = GameState(active = true, pkg = pkg, label = Apps.label(app, pkg))
        push()
    }

    fun leaveGame() {
        if (!game.value.active) return
        game.value = GameState()
        push()
    }

    /** Botón "Probar": activa el Modo Juego sin abrir el juego. */
    fun setGameTest(on: Boolean) {
        if (on) { game.value = GameState(active = true, label = "Modo de prueba", test = true); push() }
        else { game.value = GameState(); push() }
    }

    fun setVolume(v: Float) {
        if (abs(v - volume.value) < 0.004f) return
        volume.value = v
        push()
    }

    fun setAbHold(hold: Boolean) {
        abHold.value = hold
        push()
    }

    fun allPresets(): List<Preset> = Presets.builtIn + userPresets.value

    fun currentPreset(): Preset? = Presets.find(state.value.presetId, userPresets.value)

    fun spectrumSession(): Int = status.value.sessions.lastOrNull { it.ok }?.id ?: 0

    // --------------------------------------------------------------- presets

    fun selectPreset(id: String, remember: Boolean = true) {
        val p = Presets.find(id, userPresets.value) ?: return
        update {
            it.copy(
                presetId = p.id,
                filters = p.filters,
                macros = Macros(),
                punch = p.punch,
                extraDb = p.extraDb
            )
        }
        if (remember) device.value?.let { store.setDevicePreset(it.key, p.id) }
    }

    /** Guarda el sonido actual (macros incluidos) como preset propio. */
    fun saveCurrentAs(name: String) {
        val s = state.value
        val id = "u_" + System.currentTimeMillis()
        val p = Preset(
            id = id,
            name = name.trim().ifBlank { "Mi preset" },
            tagline = "Tu ajuste",
            category = Cat.MINE,
            filters = s.filters + s.macros.asFilters(),
            punch = s.punch,
            extraDb = s.extraDb,
            builtIn = false
        )
        userPresets.update { it + p }
        store.saveUserPresets(userPresets.value)
        selectPreset(id)
    }

    fun deleteUserPreset(id: String) {
        userPresets.update { list -> list.filterNot { it.id == id } }
        store.saveUserPresets(userPresets.value)
        if (state.value.presetId == id) selectPreset(Presets.DEFAULT_ID, remember = false)
    }

    /** @return cuántos filtros se importaron (0 = el texto no era un perfil válido). */
    fun importAutoEq(text: String, name: String): Int {
        val filters = AutoEq.parse(text)
        if (filters.isEmpty()) return 0
        val id = "u_" + System.currentTimeMillis()
        val p = Preset(id, name.trim().ifBlank { "AutoEq" }, "Importado de AutoEq", Cat.MINE, filters, 0.2f, 0f, false)
        userPresets.update { it + p }
        store.saveUserPresets(userPresets.value)
        selectPreset(id)
        return filters.size
    }

    fun resetFactory() {
        val keep = state.value.capture
        val f = Presets.factoryState()
        update { f.copy(capture = keep) }
        device.value?.let { store.setDevicePreset(it.key, Presets.DEFAULT_ID) }
    }

    // --------------------------------------------------------------- filtros

    fun setFilter(index: Int, f: Filter) = update { s ->
        if (index !in s.filters.indices) s
        else s.copy(filters = s.filters.toMutableList().also { it[index] = f })
    }

    fun addFilter(f: Filter) = update { s ->
        if (s.filters.size >= 16) s else s.copy(filters = s.filters + f)
    }

    fun removeFilter(index: Int) = update { s ->
        if (index !in s.filters.indices) s
        else s.copy(filters = s.filters.toMutableList().also { it.removeAt(index) })
    }

    // --------------------------------------------------------------- salida

    /** Lo llama [DeviceWatcher] cuando cambia la salida de audio principal. */
    fun onDevice(info: DeviceInfo) {
        device.value = info
        val mapped = store.devicePreset(info.key)
        if (mapped != null && Presets.find(mapped, userPresets.value) != null) {
            if (mapped != state.value.presetId) selectPreset(mapped, remember = false)
        } else if (!info.isHeadphones) {
            selectPreset(Presets.SPEAKER_ID, remember = false)
        } else if (state.value.presetId == Presets.SPEAKER_ID) {
            selectPreset(Presets.DEFAULT_ID, remember = false)
        }
    }

    fun deviceIsRemembered(): Boolean {
        val d = device.value ?: return false
        return store.devicePreset(d.key) == state.value.presetId
    }
}
