package com.eqforge.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.eqforge.audio.Bands
import com.eqforge.audio.Curve
import com.eqforge.audio.Filter
import com.eqforge.audio.FilterType
import com.eqforge.audio.Forge
import com.eqforge.audio.Macros
import com.eqforge.audio.Preset
import com.eqforge.audio.Presets
import com.eqforge.audio.Psycho
import com.eqforge.audio.Spectrum
import java.util.Locale
import kotlin.math.abs
import kotlin.math.round

@Composable
fun HomeScreen(micGranted: Boolean, onRequestMic: () -> Unit, onOpenPresets: () -> Unit) {
    val st by Forge.state.collectAsState()
    val rendered by Forge.rendered.collectAsState()
    val status by Forge.status.collectAsState()
    val device by Forge.device.collectAsState()
    val user by Forge.userPresets.collectAsState()
    val bars by Spectrum.bars.collectAsState()
    val volume by Forge.volume.collectAsState()
    var selected by remember { mutableIntStateOf(-1) }

    LaunchedEffect(st.presetId) { selected = -1 }

    val preset = Presets.find(st.presetId, user)
    val modified = preset == null || st.filters != preset.filters || !st.macros.isFlat ||
        abs(st.punch - preset.punch) > 0.005f || st.extraDb != preset.extraDb

    val total = remember(st.filters, st.macros, rendered) {
        val base = Curve.sampleLog(st.filters + st.macros.asFilters(), 160)
        val comp = rendered?.loudnessCompDb
        if (comp == null) base
        else FloatArray(base.size) { i -> base[i] + Bands.interpolate(comp, Bands.tToHz(i / (base.size - 1f))) }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // ------------------------------------------------------------ cabecera
        Row(
            Modifier.fillMaxWidth().padding(top = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                T("EqForge", 30, C.text, font = Cond)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(7.dp).clip(CircleShape).background(if (st.enabled) C.ice else C.faint))
                    Spacer(Modifier.width(7.dp))
                    val remembered = Forge.deviceIsRemembered()
                    T(
                        (device?.label ?: "Detectando salida…") + if (remembered) "  ·  recordado" else "",
                        13, C.dim
                    )
                }
            }
            PowerButton(st.enabled) { Forge.update { it.copy(enabled = !it.enabled) } }
        }

        // ---------------------------------------------------------------- hero
        Box(Modifier.fillMaxWidth().height(270.dp).card(28)) {
            CurveEditor(
                filters = st.filters,
                total = total,
                spectrum = bars,
                selected = selected,
                onSelect = { selected = it },
                onMove = { i, hz, db ->
                    Forge.state.value.filters.getOrNull(i)?.let {
                        Forge.setFilter(i, it.copy(freq = hz, gainDb = (round(db * 10f) / 10f).coerceIn(-12f, 12f)))
                    }
                },
                onAdd = { hz, db ->
                    val n = Forge.state.value.filters.size
                    Forge.addFilter(Filter(FilterType.PEAK, hz, (round(db * 10f) / 10f).coerceIn(-12f, 12f), 1.0f))
                    selected = n
                },
                modifier = Modifier.fillMaxSize()
            )
            Column(Modifier.align(Alignment.TopStart).padding(start = 18.dp, top = 14.dp)) {
                T(preset?.name ?: "Personalizado", 26, C.text, font = Cond)
                if (modified) T("Modificado", 12, C.hot, FontWeight.Medium)
                else T(preset?.tagline ?: "", 12, C.dim)
            }
            if (!micGranted) {
                Pill(
                    "Activar espectro", onRequestMic,
                    Modifier.align(Alignment.TopEnd).padding(12.dp)
                )
            }
            Box(
                Modifier
                    .align(Alignment.BottomEnd)
                    .padding(12.dp)
                    .clip(RoundedCornerShape(50))
                    .background(C.surface2)
                    .border(1.dp, C.line, RoundedCornerShape(50))
                    .pointerInput(Unit) {
                        detectTapGestures(onPress = {
                            Forge.setAbHold(true)
                            tryAwaitRelease()
                            Forge.setAbHold(false)
                        })
                    }
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                T("Mantén: sin EQ", 12, C.text, FontWeight.Medium)
            }
        }

        // -------------------------------------------------------- editor nodo
        val node = st.filters.getOrNull(selected)
        AnimatedVisibility(visible = node != null) {
            if (node != null) NodeEditor(selected, node)
        }

        // --------------------------------------------------------------- sonidos
        Section("Sonidos", trailing = "Ver todos", onTrailing = onOpenPresets)
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(horizontal = 2.dp)
        ) {
            items(Presets.builtIn + user, key = { it.id }) { p ->
                PresetCard(p, p.id == st.presetId, { Forge.selectPreset(p.id) }, Modifier.width(150.dp))
            }
        }

        // ------------------------------------------------------------------ tono
        Column(Modifier.fillMaxWidth().card().padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                T("Tono", 20, C.text, font = Cond)
                if (!st.macros.isFlat) {
                    T("Reiniciar", 13, C.hot, FontWeight.Medium, modifier = Modifier.tap {
                        Forge.update { it.copy(macros = Macros()) }
                    })
                } else T("±6 dB encima del preset", 12, C.faint)
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Fader("Sub", "50 Hz", st.macros.sub, { v -> Forge.update { it.copy(macros = it.macros.copy(sub = v)) } }, hzColor(50f))
                Fader("Graves", "110 Hz", st.macros.bass, { v -> Forge.update { it.copy(macros = it.macros.copy(bass = v)) } }, hzColor(110f))
                Fader("Cuerpo", "260 Hz", st.macros.body, { v -> Forge.update { it.copy(macros = it.macros.copy(body = v)) } }, hzColor(260f))
                Fader("Voz", "2.8 kHz", st.macros.voice, { v -> Forge.update { it.copy(macros = it.macros.copy(voice = v)) } }, hzColor(2800f))
                Fader("Brillo", "9 kHz", st.macros.air, { v -> Forge.update { it.copy(macros = it.macros.copy(air = v)) } }, hzColor(9000f))
            }
        }

        // ------------------------------------------------------------- dinámica
        Column(Modifier.fillMaxWidth().card().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            T("Dinámica", 20, C.text, font = Cond)

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                T("Punch", 14, C.text, FontWeight.Medium)
                T("${(st.punch * 100).toInt()}%", 14, C.dim)
            }
            HSlider(st.punch, { v -> Forge.update { it.copy(punch = v) } }, 0f, 1f, color = hzColor(100f), step = 0.01f)
            T("Compresión multibanda de ataque lento: aprieta los graves sin matar el golpe del kick.", 12, C.faint, maxLines = 3)

            Spacer(Modifier.height(4.dp))
            T("Volumen estilo Spotify", 14, C.text, FontWeight.Medium)
            val extraIdx = when {
                st.extraDb < 1.5f -> 0
                st.extraDb < 4f -> 1
                else -> 2
            }
            Segmented(listOf("Normal", "Alto  +3 dB", "Turbo  +5 dB"), extraIdx, { i ->
                Forge.update { it.copy(extraDb = listOf(0f, 3f, 5f)[i]) }
            })
            T("Spotify normaliza a −14 LUFS y en «Alto» a −11. Aquí subes la misma diferencia con un limitador a −1 dB (5 ms / 100 ms, igual que el suyo).", 12, C.faint, maxLines = 4)

            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    T("Loudness inteligente", 14, C.text, FontWeight.Medium)
                    T("Devuelve los graves y el aire que el oído pierde al bajar el volumen (ISO 226).", 12, C.faint, maxLines = 3)
                }
                Spacer(Modifier.width(12.dp))
                Toggle(st.smartLoudness) { v -> Forge.update { it.copy(smartLoudness = v) } }
            }
            if (st.smartLoudness) {
                HSlider(st.smartStrength, { v -> Forge.update { it.copy(smartStrength = v) } }, 0f, 1f, color = hzColor(5000f), step = 0.05f)
                val comp = rendered?.loudnessCompDb
                val bassComp = comp?.getOrNull(3) ?: 0f
                val airComp = comp?.lastOrNull() ?: 0f
                T(
                    "Volumen ${(volume * 100).toInt()}%  ·  ~${Psycho.listenPhon(volume).toInt()} phon  ·  ${fmtDb(bassComp)} dB graves  ·  ${fmtDb(airComp)} dB aire",
                    12, C.dim, maxLines = 2
                )
            }
        }

        // ---------------------------------------------------------- estado Spotify
        val live = status.sessions.firstOrNull { it.ok }
        Row(
            Modifier.fillMaxWidth().card(20).padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(if (live != null || (status.globalOk && status.globalInUse)) C.ice else C.faint))
            Spacer(Modifier.width(12.dp))
            Column {
                T(
                    when {
                        !status.running -> "Motor detenido"
                        live != null -> "Conectado a ${live.label}"
                        status.globalOk && status.globalInUse -> "Procesando la mezcla global"
                        else -> "Esperando a tu reproductor…"
                    },
                    14, C.text, FontWeight.Medium
                )
                T(
                    when {
                        live != null -> "Sesión ${live.id} · ${status.backend}"
                        status.globalOk && status.globalInUse -> status.backend
                        else -> "Dale play en Spotify, o ábrelo en Ajustes → Reproducción → Ecualizador."
                    },
                    12, C.dim, maxLines = 3
                )
            }
        }

        Spacer(Modifier.height(24.dp))
    }
}

// ------------------------------------------------------------------ editor de nodo

@Composable
private fun NodeEditor(index: Int, f: Filter) {
    Column(Modifier.fillMaxWidth().card(22).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val types = listOf(FilterType.PEAK to "Campana", FilterType.LOW_SHELF to "Graves", FilterType.HIGH_SHELF to "Agudos")
            types.forEach { (t, name) ->
                val sel = f.type == t
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (sel) hzColor(f.freq) else C.surface2)
                        .tap { Forge.setFilter(index, f.copy(type = t)) }
                        .padding(vertical = 9.dp),
                    contentAlignment = Alignment.Center
                ) {
                    T(name, 13, if (sel) Color(0xFF0E0B26) else C.dim, FontWeight.Medium, align = TextAlign.Center)
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Stepper(
                "Frecuencia", fmtHz(f.freq),
                { Forge.state.value.filters.getOrNull(index)?.let { c -> Forge.setFilter(index, c.copy(freq = (c.freq / 1.0293f).coerceAtLeast(Bands.MIN_HZ))) } },
                { Forge.state.value.filters.getOrNull(index)?.let { c -> Forge.setFilter(index, c.copy(freq = (c.freq * 1.0293f).coerceAtMost(Bands.MAX_HZ))) } }
            )
            Stepper(
                "Ganancia", fmtDb(f.gainDb) + " dB",
                { Forge.state.value.filters.getOrNull(index)?.let { c -> Forge.setFilter(index, c.copy(gainDb = (round((c.gainDb - 0.1f) * 10f) / 10f).coerceAtLeast(-12f))) } },
                { Forge.state.value.filters.getOrNull(index)?.let { c -> Forge.setFilter(index, c.copy(gainDb = (round((c.gainDb + 0.1f) * 10f) / 10f).coerceAtMost(12f))) } }
            )
            Stepper(
                "Q", String.format(Locale.US, "%.2f", f.q),
                { Forge.state.value.filters.getOrNull(index)?.let { c -> Forge.setFilter(index, c.copy(q = (round((c.q - 0.05f) * 100f) / 100f).coerceAtLeast(0.2f))) } },
                { Forge.state.value.filters.getOrNull(index)?.let { c -> Forge.setFilter(index, c.copy(q = (round((c.q + 0.05f) * 100f) / 100f).coerceAtMost(8f))) } }
            )
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            T("Mantén + o − para ajustar rápido", 12, C.faint)
            T("Eliminar nodo", 13, C.hot, FontWeight.Medium, modifier = Modifier.tap { Forge.removeFilter(index) })
        }
    }
}

@Composable
private fun Stepper(label: String, value: String, onMinus: () -> Unit, onPlus: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        T(label, 11, C.faint, align = TextAlign.Center)
        Spacer(Modifier.height(2.dp))
        T(value, 15, C.text, FontWeight.Medium, align = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            RepeatButton("−", onMinus)
            RepeatButton("+", onPlus)
        }
    }
}

// ------------------------------------------------------------------ tarjeta preset

@Composable
fun PresetCard(
    p: Preset,
    active: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    onLongPress: (() -> Unit)? = null
) {
    val shape = RoundedCornerShape(20.dp)
    val samples = remember(p.id, p.filters) { Curve.sampleLog(p.filters, 48) }
    Column(
        modifier
            .clip(shape)
            .background(if (active) C.surface2 else C.surface)
            .border(if (active) 1.8.dp else 1.dp, if (active) C.hot else C.line, shape)
            .pointerInput(p.id) {
                detectTapGestures(onTap = { onClick() }, onLongPress = { onLongPress?.invoke() })
            }
            .padding(12.dp)
    ) {
        MiniCurve(samples, Modifier.fillMaxWidth().height(44.dp), alpha = if (active) 1f else 0.8f)
        Spacer(Modifier.height(8.dp))
        T(p.name, 18, if (active) C.text else C.text, font = Cond)
        T(p.tagline, 11, C.dim, maxLines = 2)
    }
}
