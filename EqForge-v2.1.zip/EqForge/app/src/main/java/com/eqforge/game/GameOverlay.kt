package com.eqforge.game

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.view.ContextThemeWrapper
import com.eqforge.audio.Forge
import kotlin.math.roundToInt

/**
 * Barra flotante (encima del juego) que controla SOLO el volumen de Spotify.
 * Vistas clásicas a propósito: una ventana de overlay con Compose exige montar a mano
 * lifecycle + saved-state, y aquí no hace falta. No roba el foco: el juego sigue recibiendo
 * los toques fuera de la barra. Se oculta sola tras 6 s sin tocarla.
 */
class GameOverlay(base: Context) {

    private companion object { const val HIDE_MS = 6000L }

    private val ctx = ContextThemeWrapper(base, android.R.style.Theme_DeviceDefault)
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val dp = ctx.resources.displayMetrics.density

    private var root: View? = null
    private var seek: SeekBar? = null
    private var pct: TextView? = null

    private val autoHide = Runnable { dismiss() }

    val isShowing: Boolean get() = root != null

    private fun px(v: Int) = (v * dp).roundToInt()

    fun show(): Boolean {
        if (!Perms.canOverlay(ctx)) return false
        if (root != null) { bump(); return true }

        val bar = SeekBar(ctx).apply {
            max = 100
            progress = (Forge.gameSettings.value.musicVolume * 100).roundToInt()
            progressTintList = ColorStateList.valueOf(0xFF6EE7F0.toInt())
            thumbTintList = ColorStateList.valueOf(0xFF6EE7F0.toInt())
            progressBackgroundTintList = ColorStateList.valueOf(0xFF343072.toInt())
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    pct?.text = "$p%"
                    Forge.setMusicVolume(p / 100f)
                    bump()
                }
                override fun onStartTrackingTouch(s: SeekBar) { main.removeCallbacks(autoHide) }
                override fun onStopTrackingTouch(s: SeekBar) { bump() }
            })
        }
        val label = TextView(ctx).apply {
            text = "♪ Spotify"
            setTextColor(0xFFF4F1FF.toInt()); textSize = 13f
        }
        val percent = TextView(ctx).apply {
            text = "${bar.progress}%"
            setTextColor(0xFFA19BD6.toInt()); textSize = 13f
            minWidth = px(38); gravity = Gravity.END
        }
        val close = TextView(ctx).apply {
            text = "✕"
            setTextColor(0xFFA19BD6.toInt()); textSize = 16f
            setPadding(px(10), px(4), px(4), px(4))
            setOnClickListener { dismiss() }
        }
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(px(14), px(8), px(10), px(8))
            background = GradientDrawable().apply {
                cornerRadius = px(24).toFloat()
                setColor(0xEE181442.toInt())
                setStroke(px(1), 0xFF343072.toInt())
            }
            addView(label)
            addView(bar, LinearLayout.LayoutParams(px(200), ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                leftMargin = px(8); rightMargin = px(4)
            })
            addView(percent)
            addView(close)
        }

        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = px(24)
        }
        return try {
            wm.addView(row, lp)
            root = row; seek = bar; pct = percent
            bump()
            true
        } catch (e: Throwable) { false }
    }

    /** Refleja cambios hechos desde fuera (botones de la notificación). */
    fun sync(volume: Float) {
        val p = (volume * 100).roundToInt()
        if (seek?.progress != p) seek?.progress = p
        pct?.text = "$p%"
    }

    fun dismiss() {
        main.removeCallbacks(autoHide)
        root?.let { try { wm.removeView(it) } catch (e: Throwable) { } }
        root = null; seek = null; pct = null
    }

    private fun bump() {
        main.removeCallbacks(autoHide)
        main.postDelayed(autoHide, HIDE_MS)
    }
}
