package com.eqforge.audio

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** Biquad RBJ precalculado: evalúa la magnitud (dB) a cualquier frecuencia. */
class Biquad(f: Filter) {
    // [b0, b1, b2, a0, a1, a2]
    private val c: DoubleArray

    init {
        val a = 10.0.pow(f.gainDb / 40.0)
        val w0 = 2.0 * PI * f.freq / Curve.FS
        val cw = cos(w0)
        val sw = sin(w0)
        val al = sw / (2.0 * max(f.q.toDouble(), 0.1))
        val s = 2.0 * sqrt(a) * al
        c = when (f.type) {
            FilterType.PEAK -> doubleArrayOf(
                1 + al * a, -2 * cw, 1 - al * a,
                1 + al / a, -2 * cw, 1 - al / a
            )
            FilterType.LOW_SHELF -> doubleArrayOf(
                a * ((a + 1) - (a - 1) * cw + s),
                2 * a * ((a - 1) - (a + 1) * cw),
                a * ((a + 1) - (a - 1) * cw - s),
                (a + 1) + (a - 1) * cw + s,
                -2 * ((a - 1) + (a + 1) * cw),
                (a + 1) + (a - 1) * cw - s
            )
            FilterType.HIGH_SHELF -> doubleArrayOf(
                a * ((a + 1) + (a - 1) * cw + s),
                -2 * a * ((a - 1) + (a + 1) * cw),
                a * ((a + 1) + (a - 1) * cw - s),
                (a + 1) - (a - 1) * cw + s,
                2 * ((a - 1) - (a + 1) * cw),
                (a + 1) - (a - 1) * cw - s
            )
        }
    }

    fun db(hz: Float): Double {
        val w = 2.0 * PI * hz / Curve.FS
        val c1 = cos(w)
        val c2 = cos(2.0 * w)
        val num = c[0] * c[0] + c[1] * c[1] + c[2] * c[2] + 2.0 * (c[0] * c[1] + c[1] * c[2]) * c1 + 2.0 * c[0] * c[2] * c2
        val den = c[3] * c[3] + c[4] * c[4] + c[5] * c[5] + 2.0 * (c[3] * c[4] + c[4] * c[5]) * c1 + 2.0 * c[3] * c[5] * c2
        return 10.0 * log10(max(num, 1e-20) / max(den, 1e-20))
    }
}

object Curve {
    const val FS = 48000.0

    fun bank(filters: List<Filter>): List<Biquad> = filters.map { Biquad(it) }

    fun sumDb(bank: List<Biquad>, hz: Float): Float {
        var s = 0.0
        for (b in bank) s += b.db(hz)
        return s.toFloat()
    }

    /** Curva suave para dibujar: [points] muestras log-espaciadas entre 20 Hz y 20 kHz. */
    fun sampleLog(filters: List<Filter>, points: Int = 160): FloatArray {
        val bank = bank(filters)
        return FloatArray(points) { i -> sumDb(bank, Bands.tToHz(i / (points - 1f))) }
    }

    /** Ganancia de la curva en cada centro de banda del motor. */
    fun atCenters(filters: List<Filter>): FloatArray {
        val bank = bank(filters)
        return FloatArray(Bands.centers.size) { i -> sumDb(bank, Bands.centers[i]) }
    }
}
