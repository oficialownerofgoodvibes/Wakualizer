package com.eqforge.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Al arrancar el teléfono, TWS Sound (o tu último sonido) ya está activo. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            DspService.start(context)
        }
    }
}
