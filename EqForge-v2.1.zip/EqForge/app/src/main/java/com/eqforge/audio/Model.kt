package com.eqforge.audio

/** Tipos de filtro paramétrico (los mismos que usa AutoEq: PK / LSC / HSC). */
enum class FilterType { PEAK, LOW_SHELF, HIGH_SHELF }

/**
 * Un filtro paramétrico "milimétrico": tipo + frecuencia exacta + ganancia + Q.
 * Todo preset de EqForge es una lista de estos; el motor evalúa la respuesta
 * real de los biquads (RBJ) y la proyecta a las bandas del DynamicsProcessing.
 */
data class Filter(
    val type: FilterType = FilterType.PEAK,
    val freq: Float = 1000f,
    val gainDb: Float = 0f,
    val q: Float = 1f
)

/**
 * Los 5 "faders de tono" de la pantalla principal. Cada uno es un filtro fijo
 * que se suma encima del preset. Harman/Olive: casi todos los gustos se cubren
 * con un target base + ajustes de ±3 dB en graves y agudos.
 */
data class Macros(
    val sub: Float = 0f,
    val bass: Float = 0f,
    val body: Float = 0f,
    val voice: Float = 0f,
    val air: Float = 0f
) {
    val isFlat: Boolean get() = sub == 0f && bass == 0f && body == 0f && voice == 0f && air == 0f

    fun asFilters(): List<Filter> {
        val out = ArrayList<Filter>(5)
        if (sub != 0f) out += Filter(FilterType.LOW_SHELF, 50f, sub, 0.7f)
        if (bass != 0f) out += Filter(FilterType.PEAK, 110f, bass, 0.9f)
        if (body != 0f) out += Filter(FilterType.PEAK, 260f, body, 0.7f)
        if (voice != 0f) out += Filter(FilterType.PEAK, 2800f, voice, 0.9f)
        if (air != 0f) out += Filter(FilterType.HIGH_SHELF, 9000f, air, 0.7f)
        return out
    }
}

enum class CaptureMode {
    /** Sesiones anunciadas (Spotify, YT Music...) y, mientras no haya ninguna, sesión global. */
    AUTO,
    /** Solo la sesión global 0 (deprecada por Android; solo funciona en algunos equipos). */
    GLOBAL,
    /** Solo las sesiones que cada app anuncia. */
    SESSIONS
}

object Cat {
    const val SIGNATURE = "Firma"
    const val REFERENCE = "Referencia"
    const val GENRE = "Géneros"
    const val SCENE = "Escenas"
    const val MINE = "Mías"
    val all = listOf(SIGNATURE, REFERENCE, GENRE, SCENE, MINE)
}

data class Preset(
    val id: String = "",
    val name: String = "",
    val tagline: String = "",
    val category: String = Cat.MINE,
    val filters: List<Filter> = emptyList(),
    /** 0..1 intensidad del compresor multibanda. */
    val punch: Float = 0f,
    /** Ganancia extra limpia (0 / 3 / 5 dB): "Alto" y "Turbo" de la UI. */
    val extraDb: Float = 0f,
    val builtIn: Boolean = false
)

/** Todo lo que define el sonido actual. Se persiste completo. */
data class SoundState(
    val enabled: Boolean = true,
    val presetId: String = "tws",
    val filters: List<Filter> = emptyList(),
    val macros: Macros = Macros(),
    val punch: Float = 0.45f,
    val extraDb: Float = 0f,
    val smartLoudness: Boolean = true,
    val smartStrength: Float = 0.6f,
    val subsonic: Boolean = true,
    /** Qué fracción del pico de ganancia se compensa con preamp (0.4..1). */
    val headroom: Float = 0.75f,
    val ceilingDb: Float = -1f,
    /** Offsets de threshold (dB) por banda del compresor: Graves / Cuerpo / Presencia / Aire. */
    val mbcOffsets: List<Float> = listOf(0f, 0f, 0f, 0f),
    val bassBoost: Int = 0,
    val virtualizer: Int = 0,
    val capture: CaptureMode = CaptureMode.AUTO
)

data class SessionInfo(val id: Int, val pkg: String?, val ok: Boolean, val label: String)

data class EngineStatus(
    val running: Boolean = false,
    val backend: String = "—",
    val globalOk: Boolean = false,
    val globalError: String? = null,
    val globalInUse: Boolean = false,
    val sessions: List<SessionInfo> = emptyList()
)

data class DeviceInfo(val key: String, val label: String, val isHeadphones: Boolean)
