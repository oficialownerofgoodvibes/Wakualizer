package com.eqforge.audio

import android.media.audiofx.Visualizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.log10
import kotlin.math.log2
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Analizador de espectro REAL (FFT del Visualizer) en barras logarítmicas
 * 20 Hz..20 kHz, con inclinación de +3 dB/octava (como los analizadores de
 * estudio) para que los agudos no se vean planos.
 *
 * Se engancha a la sesión que Spotify anuncia (si hay) o a la global.
 */
object Spectrum {
    const val BARS = 48

    val bars = MutableStateFlow(FloatArray(BARS))

    private var viz: Visualizer? = null
    private var session = -1
    private val smooth = FloatArray(BARS)

    private val listener = object : Visualizer.OnDataCaptureListener {
        override fun onWaveFormDataCapture(v: Visualizer?, waveform: ByteArray?, samplingRate: Int) {}
        override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, samplingRate: Int) {
            if (fft != null) process(fft, samplingRate)
        }
    }

    fun start(sessionId: Int): Boolean {
        if (viz != null && session == sessionId) return true
        stop()
        return try {
            val v = Visualizer(sessionId)
            v.setEnabled(false)
            v.setCaptureSize(Visualizer.getCaptureSizeRange()[1])
            v.setDataCaptureListener(listener, Visualizer.getMaxCaptureRate(), false, true)
            v.setEnabled(true)
            viz = v
            session = sessionId
            true
        } catch (e: Throwable) {
            viz = null
            session = -1
            false
        }
    }

    fun stop() {
        try { viz?.setEnabled(false) } catch (e: Throwable) { }
        try { viz?.release() } catch (e: Throwable) { }
        viz = null
        session = -1
        smooth.fill(0f)
        bars.value = FloatArray(BARS)
    }

    val isRunning: Boolean get() = viz != null

    private fun process(fft: ByteArray, srMilliHz: Int) {
        val n = fft.size
        val half = n / 2
        if (half < 8) return
        val hzPerBin = (srMilliHz / 1000f) / n
        val mags = FloatArray(half)
        mags[0] = abs(fft[0].toInt()).toFloat()
        for (k in 1 until half) {
            mags[k] = hypot(fft[2 * k].toFloat(), fft[2 * k + 1].toFloat())
        }
        val out = FloatArray(BARS)
        for (b in 0 until BARS) {
            val f0 = Bands.tToHz(b / BARS.toFloat())
            val f1 = Bands.tToHz((b + 1) / BARS.toFloat())
            val k0 = (f0 / hzPerBin).toInt().coerceIn(1, half - 1)
            val k1 = (f1 / hzPerBin).toInt().coerceIn(k0, half - 1)
            var peak = 0f
            for (k in k0..k1) peak = max(peak, mags[k])
            val db = 20f * log10(peak + 1f)
            val tilt = 3f * log2(sqrt(f0 * f1) / 1000f)
            val v = ((db + tilt) / 46f).coerceIn(0f, 1f)
            smooth[b] = if (v > smooth[b]) smooth[b] * 0.35f + v * 0.65f else smooth[b] * 0.86f + v * 0.14f
            out[b] = smooth[b]
        }
        bars.value = out
    }
}
