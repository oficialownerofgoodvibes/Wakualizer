package com.eqforge

import android.app.Application
import com.eqforge.audio.Forge

class EqForgeApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Un solo punto de arranque: UI, servicio, tile y boot comparten el mismo estado.
        Forge.init(this)
    }
}
