package com.eqforge.game

import com.eqforge.audio.Filter
import com.eqforge.audio.FilterType
import kotlin.math.log10

/** Ajustes persistentes del Modo Juego. */
data class GameSettings(
    /** Detección automática de juegos (necesita acceso de uso). */
    val detect: Boolean = true,
    /** Paquetes vigilados: al abrir cualquiera se activa el Modo Juego. */
    val watched: Set<String> = emptySet(),
    /** Nivel de Spotify dentro del juego (0..1). Se aplica solo al detectar el juego y se restaura al salir. */
    val musicVolume: Float = 0.4f,
    /** Abrir un hueco en los medios de la música para que se oigan los pasos. */
    val carve: Boolean = true,
    val carveStrength: Float = 0.6f
)

/** Estado en tiempo de ejecución (no se guarda). */
data class GameState(
    val active: Boolean = false,
    val pkg: String? = null,
    val label: String = "",
    /** true = lo activó el botón "Probar", no un juego real. */
    val test: Boolean = false
)

object GameTuning {
    /**
     * Hueco para pasos: dos recortes suaves en la música (1.8 kHz y 3.6 kHz) donde suele
     * vivir el transitorio de los pasos. Es un punto de partida: afínalo de oído.
     */
    fun carve(strength: Float): List<Filter> {
        val s = strength.coerceIn(0f, 1f)
        if (s < 0.02f) return emptyList()
        return listOf(
            Filter(FilterType.PEAK, 1800f, -5.0f * s, 0.8f),
            Filter(FilterType.PEAK, 3600f, -4.5f * s, 0.9f)
        )
    }

    /** 0..1 -> dB. Curva 40·log10: 50 % ≈ -12 dB, 10 % ≈ -40 dB, 0 = silencio. */
    fun volumeToDb(v: Float): Float = when {
        v >= 0.999f -> 0f
        v <= 0.005f -> -80f
        else -> (40f * log10(v)).coerceAtLeast(-60f)
    }
}

/** Lo que el motor necesita para tratar distinto a la música (Spotify). */
class Mix(val music: com.eqforge.audio.Rendered?, val musicGainDb: Float) {
    companion object { val NONE = Mix(null, 0f) }
}
