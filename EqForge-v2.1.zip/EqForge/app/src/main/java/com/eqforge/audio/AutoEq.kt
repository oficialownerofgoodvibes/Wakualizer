package com.eqforge.audio

/**
 * Importa perfiles "ParametricEQ.txt" de AutoEq / Equalizer APO:
 *
 *   Preamp: -6.0 dB
 *   Filter 1: ON PK Fc 105 Hz Gain -2.3 dB Q 0.70
 *   Filter 2: ON LSC Fc 105 Hz Gain 4.0 dB Q 0.70
 *   Filter 3: ON HSC Fc 8000 Hz Gain -3.0 dB Q 0.70
 *
 * A diferencia del importador original (que aproximaba a 5 bandas de
 * hardware), aquí cada filtro entra tal cual como filtro paramétrico y el
 * motor evalúa la curva real. El Preamp se ignora: el headroom es automático.
 */
object AutoEq {
    private const val MAX_FILTERS = 16

    private val line = Regex(
        """Filter\s*\d*\s*:\s*ON\s+(PK|PEQ|LSC|LS|HSC|HS)\s+Fc\s+([\d.]+)\s*(?:Hz)?(?:\s+Gain\s+(-?[\d.]+)\s*(?:dB)?)?(?:\s+Q\s+([\d.]+))?""",
        RegexOption.IGNORE_CASE
    )

    fun parse(text: String): List<Filter> {
        val out = ArrayList<Filter>()
        for (raw in text.lineSequence()) {
            val m = line.find(raw) ?: continue
            val type = when (m.groupValues[1].uppercase()) {
                "LSC", "LS" -> FilterType.LOW_SHELF
                "HSC", "HS" -> FilterType.HIGH_SHELF
                else -> FilterType.PEAK
            }
            val fc = m.groupValues[2].toFloatOrNull() ?: continue
            val gain = m.groupValues[3].toFloatOrNull() ?: 0f
            val q = m.groupValues[4].toFloatOrNull() ?: 0.7f
            out += Filter(
                type,
                fc.coerceIn(Bands.MIN_HZ, Bands.MAX_HZ),
                gain.coerceIn(-18f, 18f),
                q.coerceIn(0.1f, 12f)
            )
            if (out.size >= MAX_FILTERS) break
        }
        return out
    }
}
