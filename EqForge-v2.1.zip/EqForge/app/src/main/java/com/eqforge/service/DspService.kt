package com.eqforge.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.audiofx.AudioEffect
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.eqforge.R
import com.eqforge.audio.DeviceWatcher
import com.eqforge.audio.Forge
import com.eqforge.audio.Presets
import com.eqforge.game.Apps
import com.eqforge.game.GameNotifier
import com.eqforge.game.GameOverlay
import com.eqforge.game.GameWatcher
import com.eqforge.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * Mantiene vivo el procesamiento. Hace tres cosas:
 *  1. Recibe los broadcasts OPEN/CLOSE_AUDIO_EFFECT_CONTROL_SESSION: así
 *     Spotify, YouTube Music y compañía nos dicen en qué sesión suenan.
 *  2. Sondea el volumen del sistema para el loudness inteligente.
 *  3. Vigila la salida de audio (TWS / cable / bocina) y reintenta cadenas caídas.
 */
class DspService : Service() {

    companion object {
        const val CHANNEL_ID = "eqforge_dsp"
        const val NOTIF_ID = 1001
        const val ACTION_TOGGLE = "com.eqforge.action.TOGGLE"
        const val ACTION_SHOW_PANEL = "com.eqforge.action.SHOW_MUSIC_PANEL"
        const val ACTION_MUSIC_UP = "com.eqforge.action.MUSIC_UP"
        const val ACTION_MUSIC_DOWN = "com.eqforge.action.MUSIC_DOWN"

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, DspService::class.java))
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private var scope: CoroutineScope? = null
    private var watcher: DeviceWatcher? = null
    private lateinit var audio: AudioManager
    private var gameWatcher: GameWatcher? = null
    private var overlay: GameOverlay? = null

    // Juego instalado después -> se vigila solo ("automatizar").
    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.getBooleanExtra(Intent.EXTRA_REPLACING, false)) return
            val pkg = intent.data?.schemeSpecificPart ?: return
            if (pkg in Apps.KNOWN_GAMES) Forge.updateGame { it.copy(watched = it.watched + pkg) }
        }
    }

    private val repostGame = Runnable {
        val g = Forge.game.value
        if (g.active) GameNotifier.post(this, g.label, Forge.gameSettings.value.musicVolume)
    }

    private val sessionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val sid = intent.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, 0)
            val pkg = intent.getStringExtra(AudioEffect.EXTRA_PACKAGE_NAME)
            when (intent.action) {
                AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION -> Forge.engine.openSession(sid, pkg)
                AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION -> Forge.engine.closeSession(sid)
            }
        }
    }

    private val poll = object : Runnable {
        override fun run() {
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val cur = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
            if (max > 0) Forge.setVolume(cur / max.toFloat())
            Forge.engine.tick()
            main.postDelayed(this, 500)
        }
    }

    override fun onCreate() {
        super.onCreate()
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        createChannel()

        val filter = IntentFilter().apply {
            addAction(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION)
            addAction(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION)
        }
        ContextCompat.registerReceiver(this, sessionReceiver, filter, ContextCompat.RECEIVER_EXPORTED)

        Forge.engine.start()

        overlay = GameOverlay(this)
        gameWatcher = GameWatcher(this).also { it.start() }
        ContextCompat.registerReceiver(
            this, pkgReceiver,
            IntentFilter(Intent.ACTION_PACKAGE_ADDED).apply { addDataScheme("package") },
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        watcher = DeviceWatcher(this).also { it.start() }
        main.post(poll)

        // Refresca la notificación cuando cambia preset o encendido.
        val sc = CoroutineScope(SupervisorJob() + Dispatchers.Main)
        scope = sc
        sc.launch {
            Forge.state.map { it.enabled to it.presetId }.distinctUntilChanged().collect {
                getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
            }
        }
        // Juego detectado -> notificación; juego cerrado -> se quita todo y Spotify vuelve a 100 %.
        sc.launch {
            Forge.game.map { it.active to it.label }.distinctUntilChanged().collect { (active, _) ->
                main.removeCallbacks(repostGame)
                if (active) repostGame.run() else { GameNotifier.cancel(this@DspService); overlay?.dismiss() }
            }
        }
        // Cambios de volumen (barra o botones de la notificación): se refleja con un pequeño retardo
        // para no pasarse del límite de actualizaciones de notificación al arrastrar.
        sc.launch {
            Forge.gameSettings.map { it.musicVolume }.distinctUntilChanged().collect { v ->
                overlay?.sync(v)
                if (Forge.game.value.active) { main.removeCallbacks(repostGame); main.postDelayed(repostGame, 300) }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_TOGGLE -> Forge.update { it.copy(enabled = !it.enabled) }
            ACTION_SHOW_PANEL -> overlay?.show()
            ACTION_MUSIC_UP -> Forge.nudgeMusic(0.1f)
            ACTION_MUSIC_DOWN -> Forge.nudgeMusic(-0.1f)
        }
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        main.removeCallbacks(poll)
        main.removeCallbacks(repostGame)
        gameWatcher?.stop()
        overlay?.dismiss()
        GameNotifier.cancel(this)
        try { unregisterReceiver(pkgReceiver) } catch (e: Exception) { }
        scope?.cancel()
        try { unregisterReceiver(sessionReceiver) } catch (e: Exception) { }
        watcher?.stop()
        Forge.engine.stop()
        super.onDestroy()
    }

    private fun createChannel() {
        val ch = NotificationChannel(CHANNEL_ID, "Procesamiento de audio", NotificationManager.IMPORTANCE_LOW).apply {
            description = "EqForge está aplicando el ecualizador a tu audio"
            setShowBadge(false)
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    private fun buildNotification(): Notification {
        val s = Forge.state.value
        val preset = Presets.find(s.presetId, Forge.userPresets.value)?.name ?: "Personalizado"
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val toggle = PendingIntent.getService(
            this, 1, Intent(this, DspService::class.java).setAction(ACTION_TOGGLE),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_equalizer)
            .setContentTitle(if (s.enabled) "EqForge · $preset" else "EqForge en pausa")
            .setContentText(if (s.enabled) "Ecualizando tu audio" else "Toca para reanudar")
            .setContentIntent(open)
            .addAction(0, if (s.enabled) "Pausar" else "Activar", toggle)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }
}
