package com.eqforge.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.drag
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.eqforge.audio.Bands
import com.eqforge.audio.Filter
import com.eqforge.audio.FilterType

private const val RANGE_DB = 15f

private fun xOf(hz: Float, w: Float) = Bands.hzToT(hz) * w
private fun yOf(db: Float, h: Float, pad: Float) =
    h / 2f - (db.coerceIn(-RANGE_DB, RANGE_DB) / RANGE_DB) * (h / 2f - pad)
private fun hzOf(x: Float, w: Float) = Bands.tToHz(x / w)
private fun dbOf(y: Float, h: Float, pad: Float) =
    ((h / 2f - y) / (h / 2f - pad) * RANGE_DB).coerceIn(-RANGE_DB, RANGE_DB)

private fun hitTest(f: List<Filter>, p: Offset, w: Float, h: Float, pad: Float, radius: Float): Int {
    var best = -1
    var bd = radius * radius
    f.forEachIndexed { i, fl ->
        val dx = xOf(fl.freq, w) - p.x
        val dy = yOf(fl.gainDb, h, pad) - p.y
        val d = dx * dx + dy * dy
        if (d < bd) { bd = d; best = i }
    }
    return best
}

/**
 * Editor paramétrico en vivo.
 *  - Fondo: espectro real (FFT) con el color de cada zona de frecuencia.
 *  - Línea: la curva TOTAL que realmente suena (preset + faders + loudness inteligente).
 *  - Nodos: un filtro cada uno. Arrastra = frecuencia y ganancia. Mantén pulsado en vacío = nodo nuevo.
 */
@Composable
fun CurveEditor(
    filters: List<Filter>,
    total: FloatArray,
    spectrum: FloatArray,
    selected: Int,
    onSelect: (Int) -> Unit,
    onMove: (Int, Float, Float) -> Unit,
    onAdd: (Float, Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val flt by rememberUpdatedState(filters)
    val onSel by rememberUpdatedState(onSelect)
    val onMv by rememberUpdatedState(onMove)
    val onAd by rememberUpdatedState(onAdd)
    val measurer = rememberTextMeasurer()
    val fillStops = remember { rampWithAlpha(0.22f) }
    val axisStyle = remember { TextStyle(color = C.faint, fontSize = 10.sp) }
    val tipStyle = remember { TextStyle(color = C.text, fontSize = 12.sp, fontWeight = FontWeight.Medium) }

    Canvas(
        modifier
            .pointerInput(Unit) {
                val pad = 22.dp.toPx()
                val radius = 30.dp.toPx()
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val w = size.width.toFloat()
                    val h = size.height.toFloat()
                    val idx = hitTest(flt, down.position, w, h, pad, radius)
                    if (idx < 0) return@awaitEachGesture
                    onSel(idx)
                    down.consume()
                    drag(down.id) { ch ->
                        ch.consume()
                        val hz = hzOf(ch.position.x.coerceIn(0f, w), w).coerceIn(Bands.MIN_HZ, Bands.MAX_HZ)
                        onMv(idx, hz, dbOf(ch.position.y, h, pad))
                    }
                }
            }
            .pointerInput(Unit) {
                val pad = 22.dp.toPx()
                val radius = 30.dp.toPx()
                detectTapGestures(
                    onTap = { o -> onSel(hitTest(flt, o, size.width.toFloat(), size.height.toFloat(), pad, radius)) },
                    onLongPress = { o ->
                        onAd(hzOf(o.x, size.width.toFloat()), dbOf(o.y, size.height.toFloat(), pad))
                    }
                )
            }
    ) {
        val w = size.width
        val h = size.height
        val pad = 22.dp.toPx()
        val zeroY = yOf(0f, h, pad)

        // Rejilla
        for (db in listOf(-12f, -6f, 6f, 12f)) {
            val y = yOf(db, h, pad)
            drawLine(C.line.copy(alpha = 0.40f), Offset(0f, y), Offset(w, y), 1.dp.toPx())
        }
        for (hz in listOf(50f, 100f, 200f, 500f, 1000f, 2000f, 5000f, 10000f)) {
            val x = xOf(hz, w)
            drawLine(C.line.copy(alpha = 0.30f), Offset(x, 0f), Offset(x, h), 1.dp.toPx())
        }
        drawLine(C.line, Offset(0f, zeroY), Offset(w, zeroY), 1.5.dp.toPx())

        // Espectro real
        val n = spectrum.size
        if (n > 0) {
            val bw = w / n
            for (i in 0 until n) {
                val v = spectrum[i]
                if (v <= 0.01f) continue
                val bh = v * h * 0.66f
                val hz = Bands.tToHz((i + 0.5f) / n)
                drawRoundRect(
                    hzColor(hz).copy(alpha = 0.26f),
                    Offset(i * bw + 1.2f, h - bh), Size(bw - 2.4f, bh), CornerRadius(2.dp.toPx())
                )
            }
        }

        // Curva total
        val pts = total.size
        if (pts > 1) {
            val line = Path()
            for (i in 0 until pts) {
                val x = w * i / (pts - 1f)
                val y = yOf(total[i], h, pad)
                if (i == 0) line.moveTo(x, y) else line.lineTo(x, y)
            }
            val fill = Path().apply {
                addPath(line)
                lineTo(w, zeroY)
                lineTo(0f, zeroY)
                close()
            }
            val ramp = Brush.horizontalGradient(*RAMP, startX = 0f, endX = w)
            drawPath(fill, Brush.horizontalGradient(*fillStops, startX = 0f, endX = w))
            drawPath(line, ramp, alpha = 0.10f, style = Stroke(14.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            drawPath(line, ramp, alpha = 0.20f, style = Stroke(7.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            drawPath(line, ramp, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        }

        // Ejes
        for ((hz, txt) in listOf(100f to "100", 1000f to "1k", 10000f to "10k")) {
            drawText(measurer.measure(txt, axisStyle), topLeft = Offset(xOf(hz, w) + 3.dp.toPx(), h - 15.dp.toPx()))
        }
        for ((db, txt) in listOf(12f to "+12", 0f to "0", -12f to "−12")) {
            drawText(measurer.measure(txt, axisStyle), topLeft = Offset(4.dp.toPx(), yOf(db, h, pad) - 14.dp.toPx()))
        }

        // Nodos
        filters.forEachIndexed { i, f ->
            val x = xOf(f.freq, w)
            val y = yOf(f.gainDb, h, pad)
            val c = hzColor(f.freq)
            val isSel = i == selected
            drawLine(c.copy(alpha = if (isSel) 0.55f else 0.22f), Offset(x, zeroY), Offset(x, y), 1.5.dp.toPx())
            drawCircle(c.copy(alpha = if (isSel) 0.30f else 0.16f), if (isSel) 17.dp.toPx() else 12.dp.toPx(), Offset(x, y))
            drawCircle(Color(0xFF0E0B26), 7.dp.toPx(), Offset(x, y))
            drawCircle(c, 5.dp.toPx(), Offset(x, y))
            if (isSel) drawCircle(Color.White, 8.5.dp.toPx(), Offset(x, y), style = Stroke(1.6.dp.toPx()))
            // forma del filtro: pequeña marca de shelf
            if (f.type != FilterType.PEAK) {
                val dir = if (f.type == FilterType.LOW_SHELF) -1f else 1f
                drawLine(c, Offset(x, y), Offset(x + dir * 14.dp.toPx(), y), 2.dp.toPx(), StrokeCap.Round)
            }
        }

        // Etiqueta del nodo seleccionado
        val s = filters.getOrNull(selected)
        if (s != null) {
            val txt = "${fmtHz(s.freq)}   ${fmtDb(s.gainDb)} dB   Q ${String.format(java.util.Locale.US, "%.2f", s.q)}"
            val lr = measurer.measure(txt, tipStyle)
            val bw = lr.size.width + 20.dp.toPx()
            val bh = lr.size.height + 10.dp.toPx()
            val nx = xOf(s.freq, w)
            val ny = yOf(s.gainDb, h, pad)
            val px = (nx - bw / 2f).coerceIn(4.dp.toPx(), w - bw - 4.dp.toPx())
            val py = if (ny > bh + 28.dp.toPx()) ny - bh - 20.dp.toPx() else ny + 20.dp.toPx()
            drawRoundRect(Color(0xE60E0B26), Offset(px, py), Size(bw, bh), CornerRadius(bh / 2f))
            drawRoundRect(C.line, Offset(px, py), Size(bw, bh), CornerRadius(bh / 2f), style = Stroke(1.dp.toPx()))
            drawText(lr, topLeft = Offset(px + 10.dp.toPx(), py + 5.dp.toPx()))
        }
    }
}
