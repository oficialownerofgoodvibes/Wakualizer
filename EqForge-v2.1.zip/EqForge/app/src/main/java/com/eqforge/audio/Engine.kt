package com.eqforge.audio

import com.eqforge.game.Apps
import com.eqforge.game.Mix
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Orquesta las cadenas de efectos.
 *
 * Contexto (doc oficial de Android): colgar efectos de la sesión global 0 está
 * DEPRECADO. Lo soportado es que cada reproductor anuncie su sesión por
 * broadcast (Spotify y YouTube Music lo hacen) y el ecualizador se enganche a
 * esa sesión. Por eso el modo AUTO usa las sesiones anunciadas y, solo cuando
 * no hay ninguna viva, la sesión global como relleno. Así nunca se procesa
 * dos veces (EQ doble = graves al doble).
 *
 * Todo corre en UN hilo; las peticiones se coalescen (arrastrar un slider no
 * encola cientos de trabajos: solo se aplica el último estado).
 */
class Engine(private val onStatus: (EngineStatus) -> Unit) {

    private class Snapshot(val r: Rendered?, val active: Boolean, val capture: CaptureMode, val mix: Mix)

    @Volatile private var snap = Snapshot(null, true, CaptureMode.AUTO, Mix.NONE)
    @Volatile private var running = false
    @Volatile private var needsRetry = false

    private val exec = Executors.newSingleThreadExecutor { r -> Thread(r, "eqforge-dsp").apply { isDaemon = true } }
    private val pending = AtomicBoolean(false)

    // Solo se tocan desde [exec]
    private var global: FxChain? = null
    private val sessions = LinkedHashMap<Int, FxChain>()

    companion object {
        private const val MAX_SESSIONS = 4

        fun appLabel(pkg: String?): String = when {
            pkg == null -> "Desconocida"
            pkg == "com.spotify.music" || pkg == "com.spotify.lite" -> "Spotify"
            pkg == "com.google.android.apps.youtube.music" -> "YouTube Music"
            pkg == "com.google.android.youtube" -> "YouTube"
            pkg.startsWith("com.amazon.mp3") -> "Amazon Music"
            pkg == "com.apple.android.music" -> "Apple Music"
            pkg == "com.soundcloud.android" -> "SoundCloud"
            pkg == "deezer.android.app" -> "Deezer"
            else -> pkg.substringAfterLast('.')
        }
    }

    fun start() {
        running = true
        request()
    }

    fun stop() {
        running = false
        exec.execute {
            global?.release(); global = null
            sessions.values.forEach { it.release() }
            sessions.clear()
            publish(false)
        }
    }

    fun submit(r: Rendered, active: Boolean, capture: CaptureMode, mix: Mix = Mix.NONE) {
        snap = Snapshot(r, active, capture, mix)
        request()
    }

    /** Llamado periódicamente por el servicio: reintenta cadenas caídas. */
    fun tick() {
        if (needsRetry) request()
    }

    fun openSession(sessionId: Int, pkg: String?) {
        if (sessionId <= 0) return
        exec.execute {
            // Spotify no cierra bien sus sesiones: una cadena viva por paquete.
            val dead = sessions.filter { (id, c) -> id == sessionId || (pkg != null && c.pkg == pkg) }.keys.toList()
            dead.forEach { sessions.remove(it)?.release() }
            while (sessions.size >= MAX_SESSIONS) {
                val oldest = sessions.keys.first()
                sessions.remove(oldest)?.release()
            }
            sessions[sessionId] = FxChain(sessionId, pkg)
            applyNow()
        }
    }

    fun closeSession(sessionId: Int) {
        exec.execute {
            sessions.remove(sessionId)?.release()
            applyNow()
        }
    }

    private fun request() {
        if (pending.compareAndSet(false, true)) {
            exec.execute {
                pending.set(false)
                applyNow()
            }
        }
    }

    private fun applyNow() {
        if (!running) { publish(false); return }
        val s = snap
        val r = s.r ?: return

        val wantGlobal = s.capture != CaptureMode.SESSIONS
        val sessionsOn = s.capture != CaptureMode.GLOBAL

        if (wantGlobal) {
            if (global == null) global = FxChain(0, null)
        } else {
            global?.release(); global = null
        }

        if (sessionsOn) sessions.values.forEach { it.ensure() }
        val anyHealthy = sessionsOn && sessions.values.any { it.alive }
        val globalInUse = wantGlobal && (s.capture == CaptureMode.GLOBAL || !anyHealthy)

        global?.apply(r, s.active && globalInUse, 0f)
        for (c in sessions.values) {
            // Solo Spotify recibe el trato de "música" (hueco para pasos + volumen propio).
            val music = c.pkg != null && c.pkg in Apps.SPOTIFY
            val rr = if (music) (s.mix.music ?: r) else r
            val gain = if (music) s.mix.musicGainDb else 0f
            c.apply(rr, s.active && sessionsOn, gain)
        }

        needsRetry = (global?.alive == false && globalInUse) || sessions.values.any { !it.alive }
        publish(globalInUse)
    }

    private fun publish(globalInUse: Boolean) {
        val g = global
        val infos = sessions.values.map { SessionInfo(it.sessionId, it.pkg, it.alive, appLabel(it.pkg)) }
        val backend = (sessions.values.firstOrNull { it.alive } ?: g)?.backend ?: "—"
        onStatus(EngineStatus(running, backend, g?.alive == true, g?.error, globalInUse, infos))
    }
}
