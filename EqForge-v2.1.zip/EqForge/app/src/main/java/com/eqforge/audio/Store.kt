package com.eqforge.audio

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

/** Persistencia en SharedPreferences (JSON con Gson). */
class Store(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("forge_v2", Context.MODE_PRIVATE)
    private val gson = Gson()

    fun loadState(): SoundState {
        val json = prefs.getString("state", null) ?: return Presets.factoryState()
        return try {
            gson.fromJson(json, SoundState::class.java) ?: Presets.factoryState()
        } catch (e: Exception) {
            Presets.factoryState()
        }
    }

    fun saveState(s: SoundState) {
        prefs.edit().putString("state", gson.toJson(s)).apply()
    }

    fun loadUserPresets(): List<Preset> {
        val json = prefs.getString("user_presets", null) ?: return emptyList()
        return try {
            val type = object : TypeToken<List<Preset>>() {}.type
            gson.fromJson<List<Preset>>(json, type) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveUserPresets(list: List<Preset>) {
        prefs.edit().putString("user_presets", gson.toJson(list)).apply()
    }

    /** null = primera vez (aún no hay ajustes de Modo Juego guardados). */
    fun loadGame(): com.eqforge.game.GameSettings? {
        val json = prefs.getString("game", null) ?: return null
        return try { gson.fromJson(json, com.eqforge.game.GameSettings::class.java) } catch (e: Exception) { null }
    }

    fun saveGame(g: com.eqforge.game.GameSettings) {
        prefs.edit().putString("game", gson.toJson(g)).apply()
    }

    /** Preset recordado por salida de audio (clave = tipo:nombre). */
    fun devicePreset(key: String): String? = prefs.getString("dev_$key", null)

    fun setDevicePreset(key: String, presetId: String) {
        prefs.edit().putString("dev_$key", presetId).apply()
    }
}
