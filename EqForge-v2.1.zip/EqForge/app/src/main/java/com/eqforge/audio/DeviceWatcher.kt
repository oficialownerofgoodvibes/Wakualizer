package com.eqforge.audio

import android.content.Context
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager

/**
 * Detecta la salida de audio principal (TWS/Bluetooth, USB, cable o bocina).
 * Cada salida recuerda el último preset que elegiste con ella conectada; si
 * es la primera vez, los audífonos conservan el sonido actual y la bocina del
 * teléfono recibe el preset "Bocina del cel" (sus bocinas no dan graves y
 * boostearlos solo gasta headroom).
 */
class DeviceWatcher(context: Context) {
    private val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var last: String? = null

    private val callback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>) = recompute()
        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>) = recompute()
    }

    fun start() {
        am.registerAudioDeviceCallback(callback, null)
        recompute()
    }

    fun stop() {
        am.unregisterAudioDeviceCallback(callback)
    }

    private val priority = listOf(
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
        AudioDeviceInfo.TYPE_BLE_HEADSET,
        AudioDeviceInfo.TYPE_USB_HEADSET,
        AudioDeviceInfo.TYPE_WIRED_HEADSET,
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES
    )

    private fun recompute() {
        val outs = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        val hp = priority.firstNotNullOfOrNull { t -> outs.firstOrNull { it.type == t } }
        val info = if (hp != null) {
            val name = hp.productName?.toString()?.trim().orEmpty()
            DeviceInfo(
                key = "${hp.type}:${name.ifBlank { "unknown" }}",
                label = name.ifBlank { genericLabel(hp.type) },
                isHeadphones = true
            )
        } else {
            DeviceInfo("speaker", "Bocina del teléfono", false)
        }
        if (info.key != last) {
            last = info.key
            Forge.onDevice(info)
        }
    }

    private fun genericLabel(type: Int): String = when (type) {
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLE_HEADSET -> "Audífonos Bluetooth"
        AudioDeviceInfo.TYPE_USB_HEADSET -> "Audífonos USB"
        else -> "Audífonos con cable"
    }
}
