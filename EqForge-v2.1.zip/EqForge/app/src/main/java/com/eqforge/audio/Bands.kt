package com.eqforge.audio

import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.sqrt

/**
 * Tabla de bandas del motor.
 *
 * OJO (bug del código original): en DynamicsProcessing la frecuencia de cada
 * banda es su TOPE SUPERIOR, no su centro; la banda i procesa desde el tope de
 * la anterior hasta el suyo. Por eso aquí los topes se calculan como el punto
 * medio geométrico entre centros vecinos de 1/3 de octava.
 *
 * Banda 0 = [0, 20 Hz]: filtro subsónico (protege bocinas diminutas de TWS y
 * regala headroom). Bandas 1..29 = centros 25 Hz .. 16 kHz.
 */
object Bands {
    val centers = floatArrayOf(
        25f, 31.5f, 40f, 50f, 63f, 80f, 100f, 125f, 160f, 200f, 250f, 315f, 400f, 500f, 630f, 800f,
        1000f, 1250f, 1600f, 2000f, 2500f, 3150f, 4000f, 5000f, 6300f, 8000f, 10000f, 12500f, 16000f
    )

    const val SUBSONIC_HZ = 20f
    const val SUBSONIC_CUT_DB = -18f
    const val TOP_HZ = 20000f

    /** Subsónico + 29 centros. */
    val count: Int = centers.size + 1

    /** Tope superior de cada banda del motor (size = count). */
    val cutoffs: FloatArray = FloatArray(count).also { c ->
        c[0] = SUBSONIC_HZ
        for (i in 1 until count - 1) c[i] = sqrt(centers[i - 1] * centers[i])
        c[count - 1] = TOP_HZ
    }

    /** Compresor multibanda de 4 bandas (zonas psicoacústicas): sub-bajo / cuerpo / presencia / aire. */
    const val MBC_COUNT = 4
    val mbcCutoffs = floatArrayOf(150f, 1500f, 6000f, 20000f)
    val mbcNames = listOf("Graves", "Cuerpo", "Presencia", "Aire")

    /** Interpola (en log-frecuencia) una lista de ganancias definidas en [centers]. */
    fun interpolate(gains: FloatArray, hz: Float): Float {
        if (hz <= centers.first()) return gains.first()
        if (hz >= centers.last()) return gains.last()
        var i = 0
        while (i < centers.size - 2 && centers[i + 1] < hz) i++
        val a = ln(centers[i]); val b = ln(centers[i + 1])
        val t = (ln(hz) - a) / (b - a)
        return gains[i] + (gains[i + 1] - gains[i]) * t
    }

    // Eje del gráfico (20 Hz .. 20 kHz, logarítmico)
    const val MIN_HZ = 20f
    const val MAX_HZ = 20000f
    private val span = ln(MAX_HZ / MIN_HZ)
    fun hzToT(hz: Float): Float = (ln(hz / MIN_HZ) / span).coerceIn(0f, 1f)
    fun tToHz(t: Float): Float = MIN_HZ * exp(span * t.coerceIn(0f, 1f))
}
