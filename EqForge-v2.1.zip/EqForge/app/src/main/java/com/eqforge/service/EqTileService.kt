package com.eqforge.service

import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.eqforge.audio.Forge
import com.eqforge.audio.Presets

/** Tile de Ajustes Rápidos: prende/apaga todo el procesamiento (A/B instantáneo). */
class EqTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        refresh()
    }

    override fun onClick() {
        super.onClick()
        DspService.start(this)
        Forge.update { it.copy(enabled = !it.enabled) }
        refresh()
    }

    private fun refresh() {
        val s = Forge.state.value
        qsTile?.apply {
            state = if (s.enabled) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            label = "EqForge"
            if (Build.VERSION.SDK_INT >= 29) {
                subtitle = if (s.enabled) {
                    Presets.find(s.presetId, Forge.userPresets.value)?.name ?: "Activo"
                } else "Desactivado"
            }
            updateTile()
        }
    }
}
