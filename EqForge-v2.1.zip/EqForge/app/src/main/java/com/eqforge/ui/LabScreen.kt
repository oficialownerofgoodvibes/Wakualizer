package com.eqforge.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.eqforge.audio.Bands
import com.eqforge.audio.CaptureMode
import com.eqforge.audio.Forge
import java.util.Locale

@Composable
fun LabScreen() {
    val st by Forge.state.collectAsState()
    val status by Forge.status.collectAsState()
    val r by Forge.rendered.collectAsState()
    var confirmReset by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column(Modifier.padding(top = 8.dp)) {
            T("Laboratorio", 30, C.text, font = Cond)
            T("Ajustes finos del motor", 13, C.dim)
        }

        // ---------------------------------------------------------------- motor
        LabCard("Motor y captura") {
            T("Dónde se engancha el ecualizador", 14, C.text, FontWeight.Medium)
            val idx = when (st.capture) { CaptureMode.AUTO -> 0; CaptureMode.GLOBAL -> 1; CaptureMode.SESSIONS -> 2 }
            Segmented(listOf("Auto", "Global", "Por app"), idx, { i ->
                Forge.update { it.copy(capture = listOf(CaptureMode.AUTO, CaptureMode.GLOBAL, CaptureMode.SESSIONS)[i]) }
            })
            T(
                "Auto: usa la sesión que anuncia cada app (Spotify, YouTube Music…) y, si no hay ninguna, la mezcla global. " +
                    "Android deprecó la sesión global, por eso «por app» es la ruta confiable. Nunca se procesa dos veces.",
                12, C.faint, maxLines = 6
            )
            StatusRow("Motor", status.backend, status.running)
            StatusRow(
                "Sesión global",
                if (status.globalOk) "disponible" else (status.globalError ?: "sin crear"),
                status.globalOk
            )
            if (status.sessions.isEmpty()) {
                StatusRow("Apps conectadas", "ninguna todavía", false)
            } else {
                status.sessions.forEach { StatusRow(it.label, "sesión ${it.id}", it.ok) }
            }
        }

        // -------------------------------------------------------------- headroom
        LabCard("Headroom y limitador") {
            val peak = r?.peakBoostDb ?: 0f
            val pre = r?.inputGainDb ?: 0f
            val match = r?.levelMatchDb ?: 0f
            T(
                "Pico de EQ ${fmtDb(peak)} dB  ·  preamp ${fmtDb(pre)} dB  ·  level match ${fmtDb(match)} dB",
                13, C.dim, maxLines = 2
            )
            LabSlider("Compensación de headroom", "${(st.headroom * 100).toInt()}%", st.headroom, 0.4f, 1f, 0.05f) { v ->
                Forge.update { it.copy(headroom = v) }
            }
            T("100% = nunca satura pero suena más bajo. 75% es el punto dulce: el limitador atrapa lo que sobre.", 12, C.faint, maxLines = 3)
            LabSlider("Techo del limitador", "${fmtDb(st.ceilingDb)} dBFS", st.ceilingDb, -3f, 0f, 0.5f) { v ->
                Forge.update { it.copy(ceilingDb = v) }
            }
            ToggleRow("Filtro subsónico (< 20 Hz)", "Quita infrasonido inaudible: protege bocinas diminutas y regala headroom.", st.subsonic) { v ->
                Forge.update { it.copy(subsonic = v) }
            }
        }

        // -------------------------------------------------------------- compresor
        LabCard("Compresor multibanda") {
            T("Offset de umbral por zona (negativo = comprime más). Punch general: ${(st.punch * 100).toInt()}%", 12, C.faint, maxLines = 3)
            for (i in 0 until Bands.MBC_COUNT) {
                val off = st.mbcOffsets.getOrElse(i) { 0f }
                val range = when (i) { 0 -> "≤ 150 Hz"; 1 -> "150 Hz – 1.5 kHz"; 2 -> "1.5 – 6 kHz"; else -> "6 – 20 kHz" }
                LabSlider("${Bands.mbcNames[i]}  ·  $range", fmtDb(off) + " dB", off, -10f, 10f, 0.5f, bipolar = true) { v ->
                    Forge.update { s ->
                        s.copy(mbcOffsets = List(Bands.MBC_COUNT) { j -> if (j == i) v else s.mbcOffsets.getOrElse(j) { 0f } })
                    }
                }
            }
        }

        // -------------------------------------------------------------- hardware
        LabCard("Efectos del fabricante (experimental)") {
            T("Dependen de tu teléfono; muchos no hacen nada con audífonos. Úsalos con cuidado: los graves del fabricante suelen embarrar.", 12, C.faint, maxLines = 4)
            LabSlider("Bass Boost", "${st.bassBoost / 10}%", st.bassBoost.toFloat(), 0f, 1000f, 50f) { v ->
                Forge.update { it.copy(bassBoost = v.toInt()) }
            }
            LabSlider("Ancho 3D (Virtualizer)", "${st.virtualizer / 10}%", st.virtualizer.toFloat(), 0f, 1000f, 50f) { v ->
                Forge.update { it.copy(virtualizer = v.toInt()) }
            }
        }

        // ----------------------------------------------------------------- reset
        LabCard("Restablecer") {
            T("Vuelve al sonido de fábrica: TWS Sound, sin faders ni ajustes finos.", 13, C.dim, maxLines = 3)
            Pill("Restablecer a TWS Sound", { confirmReset = true }, Modifier.fillMaxWidth(), filled = true)
        }
        Spacer(Modifier.height(24.dp))
    }

    if (confirmReset) {
        ConfirmDialog("¿Volver a TWS Sound de fábrica?", "Restablecer",
            onDismiss = { confirmReset = false },
            onOk = { Forge.resetFactory(); confirmReset = false })
    }
}

@Composable
private fun LabCard(title: String, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().card().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        T(title, 20, C.text, font = Cond)
        content()
    }
}

@Composable
private fun StatusRow(label: String, value: String, ok: Boolean) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(if (ok) C.ice else C.faint))
        Spacer(Modifier.width(10.dp))
        T(label, 13, C.text, FontWeight.Medium)
        Spacer(Modifier.width(10.dp))
        T(value, 12, C.dim, modifier = Modifier.weight(1f), maxLines = 2)
    }
}

@Composable
private fun LabSlider(
    label: String, valueText: String, value: Float, min: Float, max: Float, step: Float,
    bipolar: Boolean = false, onChange: (Float) -> Unit
) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            T(label, 13, C.text, FontWeight.Medium, modifier = Modifier.weight(1f))
            T(valueText, 13, C.dim)
        }
        HSlider(value, onChange, min, max, color = C.ice, step = step, bipolar = bipolar)
    }
}

@Composable
private fun ToggleRow(title: String, sub: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            T(title, 14, C.text, FontWeight.Medium)
            T(sub, 12, C.faint, maxLines = 3)
        }
        Spacer(Modifier.width(12.dp))
        Toggle(on, onChange)
    }
}
